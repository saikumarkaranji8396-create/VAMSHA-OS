export type ModuleId =
  | 'm1-chief-of-staff'
  | 'm2-wealth'
  | 'm3-property'
  | 'm4-staff'
  | 'm5-legacy'
  | 'm6-privacy'
  | 'm7-edu'
  | 'm0-billing';

export interface AuthSession {
  isAuthenticated: boolean;
  phone: string;
  principalName: string;
  jwtToken: string | null;
  issuedAt: number | null;
  expiresAt: number | null;
  device: string;
  ip: string;
  country: string;
  isNewCountryAlert: boolean;
  loginHistory: {
    timestamp: string;
    device: string;
    ip: string;
    location: string;
    flagged: boolean;
  }[];
}

export interface BillingState {
  monthlyRentUSD: number;
  setupFeeUSD: number;
  billingCycleDay: number;
  autoDebitAccount: string; // "ICICI EEFC Account (USD)"
  status: 'ACTIVE' | 'GRACE_PERIOD' | 'READ_ONLY' | 'OFFLINE_SHUTDOWN';
  gracePeriodDaysLeft: number;
  lastPaymentDate: string;
  nextBillingDate: string;
  gstNumber: string;
  fircNumber: string;
  invoices: {
    id: string;
    period: string;
    amountUSD: number;
    amountINR: number;
    status: 'PAID' | 'PENDING' | 'OVERDUE';
    gstBreakdown: { cgst: number; sgst: number; igst: number };
    fircReference: string;
    invoiceDate: string;
  }[];
}

export interface ChiefOfStaffResponse {
  query: string;
  ack: string;
  checklist: {
    step: number;
    title: string;
    details: string;
    status: 'COMPLETED' | 'IN_PROGRESS' | 'DISPATCHED' | 'PENDING';
    autoActionTriggered?: string;
  }[];
  autoActions: {
    action: string;
    target: string;
    status: 'EXECUTED_CONFIDENTIAL' | 'PENDING_CONFIRMATION' | 'DISPATCHED_TO_CONCIERGE';
  }[];
  timestamp: string;
  urgency: 'HIGH' | 'CRITICAL' | 'EXPEDITE';
}

export interface WealthAssetBreakdown {
  category: 'Banking & Liquid' | 'Indian Equities (Zerodha)' | 'Alternative & Global Real Estate' | 'Mutual Funds & PMS' | 'Sovereign Debt & Gold' | 'Crypto (Cold Storage)';
  inrCrores: number;
  usdMillions: number;
  changePct24h: number;
  accountsCount: number;
  institutions: string[];
}

export interface WealthRiskAlert {
  id: string;
  title: string;
  amountFormatted: string;
  dueDate?: string;
  severity: 'HIGH' | 'MEDIUM' | 'URGENT';
  category: 'TAX_DUE' | 'MARKET_DOWN' | 'CASH_BURN' | 'REGULATORY';
  impactDescription: string;
  actionRecommendation: string;
}

export interface PropertyAsset {
  id: string;
  name: string;
  type: 'HOUSE' | 'PRIVATE_JET' | 'YACHT';
  location: string;
  status: 'OPTIMAL' | 'ATTENTION_REQUIRED' | 'CRITICAL_WASTE';
  sensors: {
    acState: 'ON' | 'OFF' | 'MULTI_ZONE_ON';
    acRunningHoursContinuous?: number;
    doorsState: 'ALL_SECURE' | 'PATIO_AJAR' | 'HANGAR_SEALED' | 'CREW_HATCH_OPEN';
    staffPresentCount: number;
    staffResponding: boolean;
    fuelOrPowerReading: string;
    tempInside?: string;
  };
  anomalyDetected?: {
    issue: string;
    costImpactINR: number;
    costImpactDetail: string;
    recommendedRemoteAction: string;
    remoteActionLabel: string;
  };
  servicingDue: {
    serviceName: string;
    dueInDays: number;
    estimatedCost: string;
  };
}

export interface StaffMember {
  id: string;
  name: string;
  role: 'Chauffeur / Lead Driver' | 'Head Chef (Bangalore)' | 'Private Nanny' | 'Security Detail Chief' | 'Estate Butler' | 'Chief Pilot (G650)' | 'Yacht Captain';
  assignedLocation: string;
  monthlySalaryINR: number;
  advancesRequestedCount: number;
  lastAdvanceAmountINR: number;
  lastWhatsAppCheckIn: string;
  backgroundVerification: 'CLEARED_BY_KROLL' | 'PENDING_ANNUAL_REFRESH' | 'FLAGGED';
  riskLevel: 'GREEN' | 'YELLOW' | 'RED';
  evidence: string;
  recommendedAction: 'NONE' | 'DISCREET_AUDIT' | 'FORMAL_WARNING' | 'IMMEDIATE_TERMINATION_FREEZE';
  actionTaken: boolean;
}

export interface LegacyDocument {
  id: string;
  title: string;
  category: 'WILL' | 'FAMILY_TRUST' | 'CHARITY_80G' | 'OFFSHORE_STRUCTURE';
  lastAmended: string;
  nextRenewalDue: string;
  counsel: string;
  vaultStatus: 'ENCRYPTED_AIRGAP_SECURE';
  valueProtectedINR?: string;
}

export interface KidProfile {
  id: string;
  name: string;
  age: number;
  school: string;
  targetUniversities: string[];
  upcomingExams: {
    subject: string;
    examDate: string;
    targetScore: string;
    currentPredicted: string;
    gapDetected: string;
  }[];
  tutors: {
    subject: string;
    tutorName: string;
    credentials: string;
    ratingOutOf10: number;
    weeklyHours: number;
    status: 'SCHEDULED' | 'RECOMMENDED_EXTRA_HOURS';
  }[];
  focusMetrics: {
    weeklyFocusHours: number;
    targetWeeklyHours: number;
    screenHealthScore: number;
  };
  extracurriculars: {
    activity: string;
    mentor: string;
    cadence: string;
    synergyWithApplication: string;
  }[];
  monthlyEducationCostINR: number;
  weeklyReportSummary: string;
}

export interface PrivacyShieldLog {
  id: string;
  timestamp: string;
  sourceModule: string;
  destinationAttempted: string;
  dataType: string;
  decision: 'BLOCKED_AND_ISOLATED' | 'LOCAL_ENCLAVE_RESOLVED';
  reason: string;
}
