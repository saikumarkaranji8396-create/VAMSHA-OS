import React, { useState } from 'react';
import { KIDS_EDUCATION_DATA } from '../data/mockVamshaData';
import { KidProfile } from '../types/vamsha';
import {
  GraduationCap,
  Sparkles,
  Award,
  BookOpen,
  Calendar,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Plane,
  Download,
  Share2,
  Compass,
  TrendingUp,
  ShieldCheck,
  UserCheck
} from 'lucide-react';

export const VamshaEducationOS: React.FC = () => {
  const [kids, setKids] = useState<KidProfile[]>(KIDS_EDUCATION_DATA);
  const [selectedKidId, setSelectedKidId] = useState<string>('KID-01');
  const [actionNotice, setActionNotice] = useState<string | null>(null);

  const currentKid = kids.find((k) => k.id === selectedKidId) || kids[0];

  const handleExtraMathHours = () => {
    setActionNotice(`Allocated 50 emergency tutoring hours with Dr. Alistair MacIntyre. Calendar synced with Dubai villa stay.`);
    setTimeout(() => setActionNotice(null), 4000);
  };

  const handleIvyLeagueCSR = () => {
    setActionNotice(`Expanded Aarav's Clean Water Micro-Solar Desalination Foundation with IISc mentor for Ivy League application dossier.`);
    setTimeout(() => setActionNotice(null), 4000);
  };

  const handleExportWeeklyReport = () => {
    setActionNotice(`Weekly Education Report for ${currentKid.name} dispatched to Principal's private Telegram/WhatsApp.`);
    setTimeout(() => setActionNotice(null), 4000);
  };

  return (
    <div className="space-y-6">
      {/* Module Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-amber-400 font-mono tracking-wider uppercase mb-1">
            <span>MODULE 7</span>
            <span aria-hidden="true">·</span>
            <span>VAMSHA-M7-EDU</span>
            <span aria-hidden="true">·</span>
            <span>ELITE PRIVATE EDUCATION OS</span>
          </div>
          <h2 className="text-xl font-semibold text-white tracking-tight">
            Dynasty Education & Ivy League Admissions Command
          </h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            Bespoke private mentoring: IB/IGCSE faculty, Oxford & Harvard gap forecasting, etiquette, polo, grandmaster chess, 100% offline.
          </p>
        </div>

        {/* Kid Selector Tabs */}
        <div className="flex items-center gap-1.5 p-1 bg-neutral-900 border border-neutral-800 rounded">
          {kids.map((kid) => (
            <button
              key={kid.id}
              onClick={() => setSelectedKidId(kid.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors flex items-center gap-2 ${
                selectedKidId === kid.id
                  ? 'bg-neutral-800 text-white shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <GraduationCap className="w-3.5 h-3.5 text-amber-400" />
              <span>{kid.name} ({kid.age}y · {kid.id === 'KID-01' ? 'IB TISB' : 'IGCSE Aditi'})</span>
            </button>
          ))}
        </div>
      </div>

      {actionNotice && (
        <div className="p-3 bg-emerald-950/40 border border-emerald-800/80 rounded text-xs text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{actionNotice}</span>
        </div>
      )}

      {/* Distinction Banner: We are NOT Byju's */}
      <div className="p-4 bg-gradient-to-r from-amber-950/30 via-[#0C101A] to-[#0C101A] border border-amber-800/50 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-amber-400 shrink-0" />
            <strong className="text-white text-sm">Ultra-Elite Private Education Sovereign System</strong>
          </div>
          <p className="text-neutral-300 text-xs">
            We are not mass EdTech. Every faculty member is an ex-Eton don, Cambridge Tripos examiner, or Olympic grandmaster trainer, coordinated to family travel and succession milestones.
          </p>
        </div>

        <div className="text-[11px] font-mono text-emerald-400 shrink-0 px-3 py-1 bg-neutral-900 border border-neutral-800 rounded">
          100% OFFLINE DATA SECURITY
        </div>
      </div>

      {/* Target University Gap Analysis (Highlighted as requested in prompt) */}
      <div className="bg-[#0C101A] border border-neutral-800 rounded-lg p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <span className="text-[11px] font-mono text-amber-400 uppercase font-semibold">
              4. HARVARD / OXFORD ADMISSIONS GAP FORECAST
            </span>
            <h3 className="text-sm font-semibold text-white mt-0.5">
              Target: {currentKid.targetUniversities.join(' · ')}
            </h3>
          </div>
          <span className="text-xs font-mono text-neutral-400">
            Admissions Cycle: Fall 2028 Cohort
          </span>
        </div>

        {/* AI Key Quote Callout from Prompt */}
        <div className="p-4 bg-[#080B11] border border-amber-900/40 rounded-lg space-y-2">
          <div className="flex items-center gap-2 text-xs text-amber-400 font-mono">
            <Sparkles className="w-3.5 h-3.5" />
            <span>VAMSHA AI ADMISSIONS ORACLE:</span>
          </div>
          <blockquote className="text-sm text-neutral-100 font-medium italic leading-relaxed">
            "{currentKid.id === 'KID-01'
              ? 'Aarav needs 50 more hours of Math + needs community service for Ivy League.'
              : 'Ananya needs 10 extra hours of Pure Math factoring under speed conditions + documentation of Western Ghats field research for Cambridge Natural Sciences.'}"
          </blockquote>
          <div className="text-xs text-neutral-400 pt-1 flex flex-wrap gap-2">
            <button
              onClick={handleExtraMathHours}
              className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-semibold text-xs rounded transition-colors"
            >
              Auto-Schedule 50 Math Hours with Cambridge Tutor
            </button>
            <button
              onClick={handleIvyLeagueCSR}
              className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs rounded border border-neutral-700 transition-colors"
            >
              Expand Clean Water Foundation Pilot (CSR)
            </button>
          </div>
        </div>

        {/* Upcoming Exams & Predicted Scores */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {currentKid.upcomingExams.map((exam, idx) => (
            <div key={idx} className="p-3 bg-[#080B11] border border-neutral-800 rounded space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-white">{exam.subject}</span>
                <span className="text-[11px] font-mono text-neutral-400">{exam.examDate}</span>
              </div>
              <div className="text-[11px] font-mono text-amber-300">
                Target: {exam.targetScore}
              </div>
              <p className="text-[11px] text-neutral-400 leading-normal">
                {exam.gapDetected}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* 4 Core Pillars Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Pillar 1: Tutor Attendance & Quality Scores */}
        <div className="bg-[#0C101A] border border-neutral-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[11px] font-mono text-amber-400 uppercase font-semibold">
                1. TUTOR ATTENDANCE & QUALITY MATRIX
              </span>
              <h3 className="text-sm font-semibold text-white mt-0.5">
                Retained Academic Mentors
              </h3>
            </div>
            <span className="text-xs text-emerald-400 font-mono">100% Attendance Rate</span>
          </div>

          <div className="space-y-3">
            {currentKid.tutors.map((tutor, idx) => (
              <div
                key={idx}
                className="p-3 bg-[#080B11] border border-neutral-800 rounded-lg flex items-start justify-between gap-3 text-xs"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-white">{tutor.tutorName}</span>
                    <span className="text-[10px] font-mono px-1.5 py-0.2 bg-neutral-900 text-amber-400 rounded border border-neutral-700">
                      ★ {tutor.ratingOutOf10}/10 Quality
                    </span>
                  </div>
                  <div className="text-[11px] text-neutral-400 mt-0.5">{tutor.subject} · {tutor.credentials}</div>
                  <div className="text-[11px] font-mono text-neutral-500 mt-1">
                    Scheduled: {tutor.weeklyHours} hrs/week
                  </div>
                </div>

                <span
                  className={`text-[10px] font-mono px-2 py-0.5 rounded shrink-0 ${
                    tutor.status === 'RECOMMENDED_EXTRA_HOURS'
                      ? 'bg-amber-950 text-amber-300 border border-amber-800'
                      : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                  }`}
                >
                  {tutor.status === 'RECOMMENDED_EXTRA_HOURS' ? '+Hours Recommended' : 'Confirmed'}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Pillar 2 & 3: Private Tablet Focus Time & Travel Calendar Sync */}
        <div className="bg-[#0C101A] border border-neutral-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[11px] font-mono text-amber-400 uppercase font-semibold">
                2 & 3. PRIVATE TABLET TELEMETRY & FOCUS TIME
              </span>
              <h3 className="text-sm font-semibold text-white mt-0.5">
                Screen Rigor & Travel Synchronization
              </h3>
            </div>
            <span className="text-xs text-neutral-400 font-mono">
              Offline Telemetry
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs font-mono bg-[#080B11] p-3 rounded-lg border border-neutral-800">
            <div>
              <span className="text-neutral-500 text-[10px] block">WEEKLY FOCUS TIME:</span>
              <span className="text-xl font-bold text-white tabular-nums">
                {currentKid.focusMetrics.weeklyFocusHours}h
              </span>
              <span className="text-[10px] text-neutral-400 block">Target: {currentKid.focusMetrics.targetWeeklyHours}h</span>
            </div>
            <div>
              <span className="text-neutral-500 text-[10px] block">SCREEN HEALTH SCORE:</span>
              <span className="text-xl font-bold text-emerald-400 tabular-nums">
                {currentKid.focusMetrics.screenHealthScore} / 100
              </span>
              <span className="text-[10px] text-neutral-400 block">Zero social media leakage</span>
            </div>
          </div>

          {/* Extracurriculars Synced to Travel */}
          <div className="space-y-2">
            <span className="text-[11px] font-mono text-neutral-400 uppercase block">
              Extracurriculars Synced with Flight Calendar:
            </span>
            {currentKid.extracurriculars.map((act, idx) => (
              <div key={idx} className="p-2.5 bg-[#080B11] border border-neutral-800 rounded text-xs space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-white">{act.activity}</span>
                  <span className="text-[11px] font-mono text-amber-400">{act.cadence}</span>
                </div>
                <div className="text-[11px] text-neutral-400">Mentor: {act.mentor}</div>
                <div className="text-[10px] font-mono text-emerald-400">
                  Target Synergy: {act.synergyWithApplication}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Weekly Education Report for Parents & Cost Ledger */}
      <div className="bg-[#0C101A] border border-neutral-800 rounded-lg p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-800 pb-3">
          <div>
            <span className="text-[11px] font-mono text-amber-400 uppercase font-semibold">
              EXECUTIVE WEEKLY EDUCATION REPORT FOR PARENTS
            </span>
            <h3 className="text-sm font-semibold text-white mt-0.5">
              Comprehensive Scholastic Audit & Cost Reconcile
            </h3>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportWeeklyReport}
              className="px-3 py-1.5 bg-neutral-900 hover:bg-neutral-800 text-neutral-200 border border-neutral-700 text-xs rounded transition-colors flex items-center gap-1.5"
            >
              <Share2 className="w-3.5 h-3.5 text-amber-400" />
              <span>Send to Parents WhatsApp</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
          <div className="p-3 bg-[#080B11] border border-neutral-800 rounded space-y-1">
            <span className="text-neutral-500 font-mono text-[10px] block">TOTAL HOURS STUDIED</span>
            <span className="text-lg font-bold font-mono text-white tabular-nums">
              {currentKid.focusMetrics.weeklyFocusHours} Hours
            </span>
            <span className="text-[11px] text-neutral-400 block">Verified by private tablet log</span>
          </div>

          <div className="p-3 bg-[#080B11] border border-neutral-800 rounded space-y-1">
            <span className="text-neutral-500 font-mono text-[10px] block">FACULTY COMPLIANCE</span>
            <span className="text-lg font-bold font-mono text-emerald-400 tabular-nums">
              100% Punctuality
            </span>
            <span className="text-[11px] text-neutral-400 block">No missed sessions logged</span>
          </div>

          <div className="p-3 bg-[#080B11] border border-neutral-800 rounded space-y-1">
            <span className="text-neutral-500 font-mono text-[10px] block">NEXT WEEK'S CURRICULUM</span>
            <span className="text-lg font-bold font-mono text-amber-300 tabular-nums">
              13 Sessions Planned
            </span>
            <span className="text-[11px] text-neutral-400 block">Synced with Dubai Villa transition</span>
          </div>

          <div className="p-3 bg-[#080B11] border border-neutral-800 rounded space-y-1">
            <span className="text-neutral-500 font-mono text-[10px] block">MONTHLY FACULTY COST</span>
            <span className="text-lg font-bold font-mono text-white tabular-nums">
              ₹{(currentKid.monthlyEducationCostINR / 100000).toFixed(2)} Lakhs
            </span>
            <span className="text-[11px] text-neutral-400 block">ICICI Private Client auto-settle</span>
          </div>
        </div>

        {/* Narrative Summary */}
        <div className="p-3.5 bg-[#080B11] border border-neutral-800 rounded text-xs space-y-1.5">
          <span className="text-[10px] font-mono text-neutral-400 uppercase font-semibold">
            Tutor Written Narrative & Guidance:
          </span>
          <p className="text-neutral-200 leading-relaxed">
            {currentKid.weeklyReportSummary}
          </p>
        </div>
      </div>
    </div>
  );
};
