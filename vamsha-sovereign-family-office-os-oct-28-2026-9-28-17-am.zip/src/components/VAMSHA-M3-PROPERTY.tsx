import React, { useState } from 'react';
import { PROPERTY_ASSETS } from '../data/mockVamshaData';
import { PropertyAsset } from '../types/vamsha';
import {
  Building2,
  Plane,
  Anchor,
  AlertTriangle,
  Zap,
  Power,
  ShieldCheck,
  CheckCircle2,
  Clock,
  Compass,
  Wrench,
  Radio,
  Sliders
} from 'lucide-react';

export const VamshaPropertyCommander: React.FC = () => {
  const [assets, setAssets] = useState<PropertyAsset[]>(PROPERTY_ASSETS);
  const [filterType, setFilterType] = useState<'ALL' | 'HOUSE' | 'PRIVATE_JET' | 'YACHT' | 'ANOMALIES'>('ALL');
  const [activeResolutionAlert, setActiveResolutionAlert] = useState<string | null>(null);

  const handleRemoteShutoff = (assetId: string) => {
    setAssets((prev) =>
      prev.map((item) => {
        if (item.id === assetId) {
          return {
            ...item,
            status: 'OPTIMAL',
            sensors: {
              ...item.sensors,
              acState: 'OFF',
              doorsState: 'ALL_SECURE',
              fuelOrPowerReading: 'Idle Standby (0.4 kW base)',
            },
            anomalyDetected: undefined,
          };
        }
        return item;
      })
    );
    setActiveResolutionAlert(`Remote master cutoff executed via IoT relay for ${assetId}. Grid waste halted.`);
    setTimeout(() => setActiveResolutionAlert(null), 4000);
  };

  const filteredAssets = assets.filter((item) => {
    if (filterType === 'ALL') return true;
    if (filterType === 'ANOMALIES') return !!item.anomalyDetected;
    return item.type === filterType;
  });

  const totalAnomalies = assets.filter((a) => !!a.anomalyDetected).length;

  return (
    <div className="space-y-6">
      {/* Module Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-amber-400 font-mono tracking-wider uppercase mb-1">
            <span>MODULE 3</span>
            <span aria-hidden="true">·</span>
            <span>VAMSHA-M3-PROPERTY</span>
            <span aria-hidden="true">·</span>
            <span>IOT SENSOR TELEMETRY</span>
          </div>
          <h2 className="text-xl font-semibold text-white tracking-tight">
            Property & Asset Commander
          </h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            Real-time IoT grid monitoring across 10 global houses, 3 private jets, and 2 superyachts. Anomaly detection at ₹12/unit electricity pricing.
          </p>
        </div>

        {/* Filter Bar */}
        <div className="flex items-center gap-1 p-1 bg-neutral-900 border border-neutral-800 rounded">
          <button
            onClick={() => setFilterType('ALL')}
            className={`px-2.5 py-1 text-xs font-medium rounded transition-colors ${
              filterType === 'ALL' ? 'bg-neutral-800 text-white' : 'text-neutral-400 hover:text-white'
            }`}
          >
            All (15)
          </button>
          <button
            onClick={() => setFilterType('HOUSE')}
            className={`px-2.5 py-1 text-xs font-medium rounded transition-colors ${
              filterType === 'HOUSE' ? 'bg-neutral-800 text-white' : 'text-neutral-400 hover:text-white'
            }`}
          >
            10 Houses
          </button>
          <button
            onClick={() => setFilterType('PRIVATE_JET')}
            className={`px-2.5 py-1 text-xs font-medium rounded transition-colors ${
              filterType === 'PRIVATE_JET' ? 'bg-neutral-800 text-white' : 'text-neutral-400 hover:text-white'
            }`}
          >
            3 Jets
          </button>
          <button
            onClick={() => setFilterType('YACHT')}
            className={`px-2.5 py-1 text-xs font-medium rounded transition-colors ${
              filterType === 'YACHT' ? 'bg-neutral-800 text-white' : 'text-neutral-400 hover:text-white'
            }`}
          >
            2 Yachts
          </button>
          <button
            onClick={() => setFilterType('ANOMALIES')}
            className={`px-2.5 py-1 text-xs font-medium rounded transition-colors flex items-center gap-1 ${
              filterType === 'ANOMALIES' ? 'bg-rose-950 text-rose-300 border border-rose-800/60' : 'text-rose-400 hover:text-rose-300'
            }`}
          >
            <span>Waste Alerts ({totalAnomalies})</span>
          </button>
        </div>
      </div>

      {activeResolutionAlert && (
        <div className="p-3 bg-emerald-950/40 border border-emerald-800/80 rounded text-xs text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{activeResolutionAlert}</span>
        </div>
      )}

      {/* Featured Anomaly Spotlight (The Goa Villa Example) */}
      {assets.some((a) => a.id === 'PROP-01' && a.anomalyDetected) && (
        <div className="p-5 bg-gradient-to-r from-rose-950/40 via-[#0C101A] to-[#0C101A] border border-rose-800/60 rounded-lg space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-700/60">
                CRITICAL WASTE & STAFF NEGLIGENCE DETECTED
              </span>
              <span className="text-xs text-neutral-400 font-mono">
                Asset: Goa Anjuna Beachfront Villa
              </span>
            </div>
            <div className="text-xs font-mono text-rose-400">
              Indian Electricity Rate: ₹12.00 / kWh Unit
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs pt-1">
            <div className="md:col-span-2 space-y-1.5">
              <p className="text-sm font-semibold text-white">
                Goa villa master AC left ON continuously for 3 days (72 hours) with patio door ajar. Caretaker Ramesh not responding.
              </p>
              <div className="text-neutral-300 text-xs">
                <strong>Cost Impact:</strong> 676 units consumed @ ₹12.00/unit = <strong className="text-rose-400 font-mono">₹8,112 avoidable grid cost</strong> + irreversible compressor wear under high humidity.
              </div>
            </div>

            <div className="flex flex-col justify-center items-start md:items-end">
              <span className="text-[11px] text-neutral-400 mb-1.5">Auto-Action Recommendation:</span>
              <button
                onClick={() => handleRemoteShutoff('PROP-01')}
                className="w-full md:w-auto px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white font-medium text-xs rounded transition-colors flex items-center justify-center gap-2 shadow-lg"
              >
                <Power className="w-3.5 h-3.5" />
                <span>Shut Remotely (Override IoT Relay)</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Asset Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredAssets.map((asset) => {
          const hasAnomaly = !!asset.anomalyDetected;

          return (
            <div
              key={asset.id}
              className={`p-4 bg-[#0C101A] border rounded-lg flex flex-col justify-between space-y-3 ${
                hasAnomaly
                  ? 'border-rose-800/80'
                  : 'border-neutral-800 hover:border-neutral-700 transition-colors'
              }`}
            >
              <div>
                {/* Header */}
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    {asset.type === 'HOUSE' && <Building2 className="w-4 h-4 text-amber-400" />}
                    {asset.type === 'PRIVATE_JET' && <Plane className="w-4 h-4 text-sky-400" />}
                    {asset.type === 'YACHT' && <Anchor className="w-4 h-4 text-cyan-400" />}
                    <span className="text-[11px] font-mono text-neutral-400 uppercase">
                      {asset.type.replace('_', ' ')}
                    </span>
                  </div>
                  <span
                    className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                      asset.status === 'OPTIMAL'
                        ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/40'
                        : asset.status === 'CRITICAL_WASTE'
                        ? 'bg-rose-950/80 text-rose-300 border border-rose-800/60'
                        : 'bg-amber-950/60 text-amber-300 border border-amber-800/40'
                    }`}
                  >
                    {asset.status}
                  </span>
                </div>

                <h3 className="text-sm font-semibold text-white leading-tight">
                  {asset.name}
                </h3>
                <p className="text-xs text-neutral-400 mt-0.5">{asset.location}</p>

                {/* Sensor Telemetry Badges */}
                <div className="mt-3 grid grid-cols-2 gap-2 text-[11px] font-mono bg-[#080B11] p-2.5 rounded border border-neutral-800/80">
                  <div>
                    <span className="text-neutral-500 block text-[10px]">HVAC STATE:</span>
                    <span className={asset.sensors.acState === 'OFF' ? 'text-neutral-400' : 'text-amber-400'}>
                      {asset.sensors.acState}
                      {asset.sensors.acRunningHoursContinuous && ` (${asset.sensors.acRunningHoursContinuous}h)`}
                    </span>
                  </div>
                  <div>
                    <span className="text-neutral-500 block text-[10px]">ACCESS PERIMETER:</span>
                    <span className={asset.sensors.doorsState === 'ALL_SECURE' || asset.sensors.doorsState === 'HANGAR_SEALED' ? 'text-emerald-400' : 'text-rose-400'}>
                      {asset.sensors.doorsState.replace('_', ' ')}
                    </span>
                  </div>
                  <div>
                    <span className="text-neutral-500 block text-[10px]">STAFF ON SITE:</span>
                    <span className="text-neutral-200">
                      {asset.sensors.staffPresentCount} Staff · {asset.sensors.staffResponding ? 'Responding' : 'NO RESPONSE'}
                    </span>
                  </div>
                  <div>
                    <span className="text-neutral-500 block text-[10px]">LOAD / FUEL:</span>
                    <span className="text-neutral-300 truncate block">
                      {asset.sensors.fuelOrPowerReading}
                    </span>
                  </div>
                </div>

                {/* Anomaly if active */}
                {asset.anomalyDetected && (
                  <div className="mt-3 p-2.5 bg-rose-950/40 border border-rose-800/50 rounded text-xs space-y-1.5">
                    <div className="text-rose-300 font-medium">
                      ⚠️ {asset.anomalyDetected.issue}
                    </div>
                    <div className="text-[11px] text-neutral-300">
                      <strong>Impact:</strong> ₹{asset.anomalyDetected.costImpactINR.toLocaleString()} · {asset.anomalyDetected.costImpactDetail}
                    </div>
                  </div>
                )}
              </div>

              {/* Bottom Actions & Servicing Due */}
              <div className="pt-2 border-t border-neutral-800 space-y-2">
                <div className="flex items-center justify-between text-[11px] text-neutral-400 font-mono">
                  <span>Maintenance Due:</span>
                  <span className="text-amber-300">
                    {asset.servicingDue.dueInDays} days ({asset.servicingDue.estimatedCost})
                  </span>
                </div>
                <div className="text-[11px] text-neutral-500 truncate">
                  {asset.servicingDue.serviceName}
                </div>

                {asset.anomalyDetected && (
                  <button
                    onClick={() => handleRemoteShutoff(asset.id)}
                    className="w-full mt-2 py-1.5 px-3 bg-neutral-800 hover:bg-neutral-700 text-rose-300 hover:text-white text-xs font-medium rounded border border-neutral-700 transition-colors flex items-center justify-center gap-1.5"
                  >
                    <Power className="w-3.5 h-3.5" />
                    <span>{asset.anomalyDetected.remoteActionLabel}</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
