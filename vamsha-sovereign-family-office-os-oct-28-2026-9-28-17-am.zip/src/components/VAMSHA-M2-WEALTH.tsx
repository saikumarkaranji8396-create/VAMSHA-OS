import React, { useState } from 'react';
import {
  WEALTH_BREAKDOWN_DATA,
  WEALTH_TOP_RISKS,
} from '../data/mockVamshaData';
import {
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  Building,
  Landmark,
  Coins,
  FileCode,
  DollarSign,
  ArrowUpRight,
  ShieldAlert,
  CheckCircle,
  Copy,
  Check,
  RefreshCw
} from 'lucide-react';

export const VamshaWealthCockpit: React.FC = () => {
  const [viewMode, setViewMode] = useState<'DASHBOARD' | 'JSON'>('DASHBOARD');
  const [executedRisks, setExecutedRisks] = useState<string[]>([]);
  const [copiedJson, setCopiedJson] = useState(false);

  // Calculated totals
  const totalInrCrores = WEALTH_BREAKDOWN_DATA.reduce((acc, curr) => acc + curr.inrCrores, 0);
  const totalUsdMillions = WEALTH_BREAKDOWN_DATA.reduce((acc, curr) => acc + curr.usdMillions, 0);
  const totalAccounts = WEALTH_BREAKDOWN_DATA.reduce((acc, curr) => acc + curr.accountsCount, 0);

  // Change vs yesterday: +₹4.20 Cr (+0.28%) / +$502,000 USD
  const changeInrCrores = +4.2;
  const changeUsdMillions = +0.502;
  const changePct = +0.28;

  // JSON representation of cockpit state
  const cockpitJson = {
    vamsha_engine: 'VAMSHA-M2-WEALTH',
    timestamp: '2026-10-27T20:50:00+05:30',
    jurisdiction: 'IN-KA (Bangalore Family Office Enclave)',
    api_gateways: {
      setu_account_aggregator: 'CONNECTED (RBI AA License #AA-2022-09)',
      plaid_cross_border: 'CONNECTED (UK & US Private Banking)',
      zerodha_kite_connect: 'LIVE DIRECT PIPELINE (Family Trust Account)',
    },
    net_worth_today: {
      inr_crores: totalInrCrores,
      inr_formatted: `₹${totalInrCrores.toFixed(1)} Crores`,
      usd_millions: totalUsdMillions,
      usd_formatted: `$${totalUsdMillions.toFixed(1)} Million`,
    },
    change_vs_yesterday: {
      inr_delta: `+₹${changeInrCrores.toFixed(2)} Cr`,
      usd_delta: `+$${(changeUsdMillions * 1000).toFixed(0)}K`,
      percentage: `+${changePct}%`,
    },
    connected_accounts_count: totalAccounts,
    top_3_risks: WEALTH_TOP_RISKS.map((r) => ({
      id: r.id,
      title: r.title,
      severity: r.severity,
      amount: r.amountFormatted,
      alert_message: r.impactDescription,
      action_recommendation: r.actionRecommendation,
    })),
    asset_breakdown: WEALTH_BREAKDOWN_DATA,
  };

  const handleExecuteAction = (riskId: string) => {
    if (!executedRisks.includes(riskId)) {
      setExecutedRisks([...executedRisks, riskId]);
    }
  };

  const handleCopyJson = () => {
    navigator.clipboard.writeText(JSON.stringify(cockpitJson, null, 2));
    setCopiedJson(true);
    setTimeout(() => setCopiedJson(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Module Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-amber-400 font-mono tracking-wider uppercase mb-1">
            <span>MODULE 2</span>
            <span aria-hidden="true">·</span>
            <span>VAMSHA-M2-WEALTH</span>
            <span aria-hidden="true">·</span>
            <span>SETU & PLAID PIPELINES</span>
          </div>
          <h2 className="text-xl font-semibold text-white tracking-tight">
            Wealth Cockpit & Sovereign Balance Sheet
          </h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            Real-time aggregate across 30 bank accounts, Zerodha Family Trust, Mutual Funds, Physical Real Estate, and Air-gapped Crypto.
          </p>
        </div>

        {/* View Mode Toggle */}
        <div className="flex items-center gap-1 p-1 bg-neutral-900 border border-neutral-800 rounded">
          <button
            onClick={() => setViewMode('DASHBOARD')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
              viewMode === 'DASHBOARD'
                ? 'bg-neutral-800 text-white'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            Human Summary
          </button>
          <button
            onClick={() => setViewMode('JSON')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors flex items-center gap-1.5 ${
              viewMode === 'JSON'
                ? 'bg-neutral-800 text-white'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <FileCode className="w-3.5 h-3.5 text-amber-400" />
            <span>Dashboard JSON</span>
          </button>
        </div>
      </div>

      {/* Top Net Worth Today Strip */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Metric 1: Net Worth INR */}
        <div className="bg-[#0C101A] border border-neutral-800 rounded-lg p-4">
          <span className="text-[11px] font-mono text-neutral-400 uppercase tracking-wider block mb-1">
            1. Net Worth Today (INR)
          </span>
          <div className="text-2xl font-bold font-mono text-white tabular-nums tracking-tight">
            ₹{totalInrCrores.toFixed(1)} <span className="text-base font-sans text-neutral-400 font-normal">Cr</span>
          </div>
          <div className="mt-2 text-xs text-emerald-400 font-mono flex items-center gap-1">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>+₹{changeInrCrores.toFixed(2)} Cr vs yesterday</span>
          </div>
        </div>

        {/* Metric 2: Net Worth USD */}
        <div className="bg-[#0C101A] border border-neutral-800 rounded-lg p-4">
          <span className="text-[11px] font-mono text-neutral-400 uppercase tracking-wider block mb-1">
            1. Net Worth Today (USD)
          </span>
          <div className="text-2xl font-bold font-mono text-white tabular-nums tracking-tight">
            ${totalUsdMillions.toFixed(1)} <span className="text-base font-sans text-neutral-400 font-normal">M</span>
          </div>
          <div className="mt-2 text-xs text-emerald-400 font-mono flex items-center gap-1">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>+${(changeUsdMillions * 1000).toFixed(0)}K vs yesterday (+{changePct}%)</span>
          </div>
        </div>

        {/* Metric 3: Connected Accounts */}
        <div className="bg-[#0C101A] border border-neutral-800 rounded-lg p-4">
          <span className="text-[11px] font-mono text-neutral-400 uppercase tracking-wider block mb-1">
            Live Connected Portals
          </span>
          <div className="text-2xl font-bold font-mono text-white tabular-nums tracking-tight">
            {totalAccounts} <span className="text-base font-sans text-neutral-400 font-normal">Vaults</span>
          </div>
          <div className="mt-2 text-[11px] text-neutral-400">
            Setu RBI AA · Plaid UK/US · Zerodha Kite Connect
          </div>
        </div>

        {/* Metric 4: Monthly Operational Burn */}
        <div className="bg-[#0C101A] border border-neutral-800 rounded-lg p-4">
          <span className="text-[11px] font-mono text-neutral-400 uppercase tracking-wider block mb-1">
            Monthly Estate Burn
          </span>
          <div className="text-2xl font-bold font-mono text-amber-300 tabular-nums tracking-tight">
            ₹42.8 <span className="text-base font-sans text-neutral-400 font-normal">Lakhs</span>
          </div>
          <div className="mt-2 text-[11px] text-neutral-400">
            Across 10 Estates + Aviation + 2 Yachts
          </div>
        </div>
      </div>

      {viewMode === 'DASHBOARD' ? (
        <>
          {/* Top 3 Risks Section */}
          <div className="bg-[#0C101A] border border-neutral-800 rounded-lg p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[11px] font-mono text-rose-400 font-semibold uppercase">
                  3. TOP 3 CAPITAL RISKS DETECTED
                </span>
                <h3 className="text-sm font-semibold text-white mt-0.5">
                  Actionable Vulnerabilities Requiring Principal Decision
                </h3>
              </div>
              <span className="text-xs text-neutral-400 font-mono">
                Formula: Tax Due + Drawdown + Burn Anomaly
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {WEALTH_TOP_RISKS.map((risk) => {
                const isExecuted = executedRisks.includes(risk.id);
                return (
                  <div
                    key={risk.id}
                    className="p-4 bg-[#080B11] border border-neutral-800 rounded-lg flex flex-col justify-between space-y-3"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-rose-950/70 text-rose-300 border border-rose-800/40">
                          {risk.category}
                        </span>
                        {risk.dueDate && (
                          <span className="text-[11px] font-mono text-amber-400">
                            {risk.dueDate}
                          </span>
                        )}
                      </div>

                      <h4 className="text-xs font-semibold text-white leading-snug">
                        {risk.title}
                      </h4>
                      <div className="text-sm font-mono text-rose-400 font-semibold mt-1 tabular-nums">
                        {risk.amountFormatted}
                      </div>
                      <p className="text-xs text-neutral-400 mt-2 leading-relaxed">
                        {risk.impactDescription}
                      </p>
                    </div>

                    <div className="pt-3 border-t border-neutral-800">
                      <div className="text-[11px] text-neutral-300 mb-2">
                        <strong className="text-amber-400 block mb-0.5">Recommended Action:</strong>
                        <span>{risk.actionRecommendation}</span>
                      </div>

                      <button
                        onClick={() => handleExecuteAction(risk.id)}
                        disabled={isExecuted}
                        className={`w-full py-1.5 px-3 text-xs font-medium rounded transition-colors flex items-center justify-center gap-1.5 ${
                          isExecuted
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-700/60'
                            : 'bg-neutral-800 hover:bg-neutral-700 text-white border border-neutral-700'
                        }`}
                      >
                        {isExecuted ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                            <span>Remittance Dispatched</span>
                          </>
                        ) : (
                          <>
                            <ArrowUpRight className="w-3.5 h-3.5 text-amber-400" />
                            <span>Authorize & Liquidate</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Asset Class Distribution & Institutions Grid */}
          <div className="bg-[#0C101A] border border-neutral-800 rounded-lg p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[11px] font-mono text-amber-400 font-semibold uppercase">
                  ASSET COMPOSITION & JURISDICTION BREAKDOWN
                </span>
                <h3 className="text-sm font-semibold text-white mt-0.5">
                  Portfolio Liquidity & Valuation Matrix
                </h3>
              </div>
              <span className="text-xs font-mono text-neutral-400">
                100% Reconciled Today 08:30 IST
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-neutral-800 text-neutral-400 font-mono uppercase text-[11px]">
                    <th className="py-2.5 px-3">Asset Classification</th>
                    <th className="py-2.5 px-3">INR Valuation</th>
                    <th className="py-2.5 px-3">USD Equivalent</th>
                    <th className="py-2.5 px-3">24h Net Shift</th>
                    <th className="py-2.5 px-3">Accounts</th>
                    <th className="py-2.5 px-3">Custodians & Vaults</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-800/60 font-mono">
                  {WEALTH_BREAKDOWN_DATA.map((item, idx) => (
                    <tr key={idx} className="hover:bg-neutral-900/40">
                      <td className="py-3 px-3 font-medium text-white font-sans flex items-center gap-2">
                        {item.category.includes('Equities') && <TrendingUp className="w-4 h-4 text-emerald-400 shrink-0" />}
                        {item.category.includes('Real Estate') && <Building className="w-4 h-4 text-amber-400 shrink-0" />}
                        {item.category.includes('Banking') && <Landmark className="w-4 h-4 text-sky-400 shrink-0" />}
                        {item.category.includes('Crypto') && <Coins className="w-4 h-4 text-purple-400 shrink-0" />}
                        <span>{item.category}</span>
                      </td>
                      <td className="py-3 px-3 text-white font-semibold tabular-nums">
                        ₹{item.inrCrores.toFixed(1)} Cr
                      </td>
                      <td className="py-3 px-3 text-neutral-300 tabular-nums">
                        ${item.usdMillions.toFixed(1)} M
                      </td>
                      <td className="py-3 px-3 tabular-nums">
                        <span
                          className={`text-xs ${
                            item.changePct24h >= 0 ? 'text-emerald-400' : 'text-rose-400'
                          }`}
                        >
                          {item.changePct24h >= 0 ? `+${item.changePct24h}%` : `${item.changePct24h}%`}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-neutral-400 tabular-nums">
                        {item.accountsCount} accounts
                      </td>
                      <td className="py-3 px-3 text-neutral-400 text-[11px] font-sans">
                        {item.institutions.join(' · ')}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      ) : (
        /* Raw JSON Mode */
        <div className="bg-[#0C101A] border border-neutral-800 rounded-lg p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[11px] font-mono text-amber-400 font-semibold uppercase">
                RAW SOVEREIGN TELEMETRY JSON
              </span>
              <p className="text-xs text-neutral-400">
                Machine-readable Setu/Plaid normalized payload generated by VAMSHA-M2 engine.
              </p>
            </div>
            <button
              onClick={handleCopyJson}
              className="px-3 py-1.5 text-xs font-mono bg-neutral-900 hover:bg-neutral-800 text-neutral-200 border border-neutral-700 rounded transition-colors flex items-center gap-1.5"
            >
              {copiedJson ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedJson ? 'Copied to Clipboard' : 'Copy JSON'}</span>
            </button>
          </div>

          <pre className="p-4 bg-[#080B11] border border-neutral-800 rounded text-xs font-mono text-emerald-400 overflow-x-auto max-h-[480px]">
            {JSON.stringify(cockpitJson, null, 2)}
          </pre>
        </div>
      )}
    </div>
  );
};
