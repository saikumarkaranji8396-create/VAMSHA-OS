import React, { useState } from 'react';
import { LEGACY_DOCS, KIDS_EDUCATION_DATA } from '../data/mockVamshaData';
import { LegacyDocument, KidProfile } from '../types/vamsha';
import {
  FileText,
  Shield,
  HeartPulse,
  GraduationCap,
  Calendar,
  AlertCircle,
  CheckCircle,
  Building,
  UserCheck,
  Lock,
  ArrowRight
} from 'lucide-react';

export const VamshaLegacyManager: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'KIDS' | 'TRUSTS_WILLS'>('KIDS');
  const [kids, setKids] = useState<KidProfile[]>(KIDS_EDUCATION_DATA);
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  const handleBookTutor = (kidName: string, tutorName: string, hours: number) => {
    setActionMessage(`Auto-booked +${hours} hours with ${tutorName} for ${kidName}. Encrypted invoice added to monthly education ledger.`);
    setTimeout(() => setActionMessage(null), 4000);
  };

  const handleNotifyParents = (kidName: string, subject: string) => {
    setActionMessage(`Sent confidential WhatsApp Academic Diagnostic on ${kidName}'s ${subject} to Principal & Mrs. Radhika Rao.`);
    setTimeout(() => setActionMessage(null), 4000);
  };

  return (
    <div className="space-y-6">
      {/* Module Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-amber-400 font-mono tracking-wider uppercase mb-1">
            <span>MODULE 5</span>
            <span aria-hidden="true">·</span>
            <span>VAMSHA-M5-LEGACY</span>
            <span aria-hidden="true">·</span>
            <span>DYNASTY PRESERVATION</span>
          </div>
          <h2 className="text-xl font-semibold text-white tracking-tight">
            Legacy, Dynasty Trusts & Next-Gen Command
          </h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            Wills, irrevocable trusts, 80G philanthropic foundations, tutor analysis, and predictive academic gap identification for family heirs.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1 p-1 bg-neutral-900 border border-neutral-800 rounded">
          <button
            onClick={() => setActiveTab('KIDS')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors flex items-center gap-1.5 ${
              activeTab === 'KIDS' ? 'bg-neutral-800 text-white' : 'text-neutral-400 hover:text-white'
            }`}
          >
            <GraduationCap className="w-3.5 h-3.5 text-amber-400" />
            <span>Next-Gen (Aarav & Ananya)</span>
          </button>
          <button
            onClick={() => setActiveTab('TRUSTS_WILLS')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors flex items-center gap-1.5 ${
              activeTab === 'TRUSTS_WILLS' ? 'bg-neutral-800 text-white' : 'text-neutral-400 hover:text-white'
            }`}
          >
            <FileText className="w-3.5 h-3.5 text-sky-400" />
            <span>Wills & Trusts ({LEGACY_DOCS.length})</span>
          </button>
        </div>
      </div>

      {/* Privacy Notice Banner */}
      <div className="p-3 bg-[#0C101A] border border-neutral-800 rounded-lg flex items-center justify-between text-xs text-neutral-300">
        <div className="flex items-center gap-2">
          <Lock className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>
            <strong>Ironclad Privacy Mandate:</strong> Children’s photos, biometric scans, and school progress reports are strictly prohibited from cloud transit. Stored 100% offline on Bangalore Mac Mini.
          </span>
        </div>
        <span className="text-[11px] font-mono text-emerald-400 shrink-0">LOCAL VAULT: SECURE</span>
      </div>

      {actionMessage && (
        <div className="p-3 bg-emerald-950/40 border border-emerald-800/80 rounded text-xs text-emerald-300 flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{actionMessage}</span>
        </div>
      )}

      {/* Content depending on Active Tab */}
      {activeTab === 'KIDS' ? (
        <div className="space-y-6">
          {kids.map((kid) => (
            <div key={kid.id} className="bg-[#0C101A] border border-neutral-800 rounded-lg p-5 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-neutral-800 pb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-semibold text-white">{kid.name}</h3>
                    <span className="text-xs text-neutral-400">({kid.age} yrs)</span>
                    <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-neutral-900 text-amber-400 border border-neutral-700">
                      Target: {kid.targetUniversities[0]}
                    </span>
                  </div>
                  <p className="text-xs text-neutral-400 mt-0.5">{kid.school}</p>
                </div>

                <div className="flex items-center gap-3 text-xs font-mono">
                  <span className="text-neutral-400">Focus Hours:</span>
                  <strong className="text-white tabular-nums">{kid.focusMetrics.weeklyFocusHours}h / week</strong>
                </div>
              </div>

              {/* Tutor Reports & Weak Subject Predictor */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-mono text-amber-400 uppercase font-semibold">
                    PREDICTIVE ACADEMIC GAP ANALYSIS (FROM TUTOR REPORTS)
                  </span>
                  <span className="text-[11px] text-neutral-400 font-mono">
                    Updated today from Cambridge & IISc Tutors
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {kid.upcomingExams.map((exam, idx) => (
                    <div
                      key={idx}
                      className="p-3.5 bg-[#080B11] border border-neutral-800 rounded-lg space-y-2 text-xs"
                    >
                      <div className="flex items-center justify-between">
                        <h4 className="font-semibold text-white">{exam.subject}</h4>
                        <span className="text-[11px] font-mono text-neutral-400">Exam: {exam.examDate}</span>
                      </div>

                      <div className="flex items-center justify-between text-[11px] font-mono bg-neutral-900/60 p-2 rounded">
                        <span className="text-neutral-400">Target: {exam.targetScore}</span>
                        <span className={exam.currentPredicted.includes('Gap') ? 'text-rose-400' : 'text-emerald-400'}>
                          Predicted: {exam.currentPredicted}
                        </span>
                      </div>

                      <p className="text-xs text-neutral-300 leading-relaxed">
                        <strong>Gap Detected:</strong> {exam.gapDetected}
                      </p>

                      <div className="pt-2 border-t border-neutral-800/80 flex items-center gap-2">
                        <button
                          onClick={() => handleBookTutor(kid.name, kid.tutors[0]?.tutorName || 'Senior Tutor', 10)}
                          className="px-2.5 py-1 text-[11px] font-medium bg-neutral-900 hover:bg-neutral-800 text-amber-300 border border-neutral-700 rounded transition-colors"
                        >
                          Auto-Book +10h Tutor
                        </button>
                        <button
                          onClick={() => handleNotifyParents(kid.name, exam.subject)}
                          className="px-2.5 py-1 text-[11px] font-medium bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-700 rounded transition-colors"
                        >
                          Notify Parents
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Active Private Tutors */}
              <div className="pt-2">
                <span className="text-[11px] font-mono text-neutral-400 uppercase block mb-2">
                  Retained Private Faculty:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
                  {kid.tutors.map((t, idx) => (
                    <div key={idx} className="p-2.5 bg-neutral-900/60 border border-neutral-800 rounded">
                      <div className="flex items-center justify-between text-[11px]">
                        <strong className="text-white">{t.subject}</strong>
                        <span className="text-amber-400 font-mono">★ {t.ratingOutOf10}/10</span>
                      </div>
                      <div className="text-[11px] text-neutral-300 mt-0.5">{t.tutorName}</div>
                      <div className="text-[10px] text-neutral-500 truncate">{t.credentials}</div>
                      <div className="text-[10px] font-mono text-emerald-400 mt-1">{t.weeklyHours}h / week scheduled</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Health Vault Summary */}
              <div className="pt-2 border-t border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-2 text-neutral-400">
                  <HeartPulse className="w-4 h-4 text-rose-400" />
                  <span>
                    Health Record: Apollo Executive Concierge Cleared · Blood: O+ · Allergies: None · Vaccine Protocol 100% Up to Date
                  </span>
                </div>
                <span className="font-mono text-neutral-400 text-[11px]">
                  Monthly Retainer: ₹{(kid.monthlyEducationCostINR / 1000).toFixed(0)}K
                </span>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* Trusts & Wills Tab */
        <div className="bg-[#0C101A] border border-neutral-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[11px] font-mono text-amber-400 uppercase font-semibold">
                IRREVOCABLE TRUSTS & WILL REPOSITORY
              </span>
              <h3 className="text-sm font-semibold text-white mt-0.5">
                Multi-Generational Wealth Succession Architecture
              </h3>
            </div>
            <span className="text-xs text-neutral-400 font-mono">
              Enforced by Cyril Amarchand Mangaldas & Withers LLP
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-neutral-800 text-neutral-400 font-mono uppercase text-[11px]">
                  <th className="py-2.5 px-3">Instrument Title</th>
                  <th className="py-2.5 px-3">Category</th>
                  <th className="py-2.5 px-3">Protected Assets</th>
                  <th className="py-2.5 px-3">Legal Counsel</th>
                  <th className="py-2.5 px-3">Next Renewal / Review</th>
                  <th className="py-2.5 px-3">Vault Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800/60 font-mono">
                {LEGACY_DOCS.map((doc) => (
                  <tr key={doc.id} className="hover:bg-neutral-900/40">
                    <td className="py-3 px-3 font-medium text-white font-sans">
                      {doc.title}
                    </td>
                    <td className="py-3 px-3">
                      <span className="text-[10px] px-2 py-0.5 rounded bg-neutral-900 text-neutral-300 border border-neutral-700">
                        {doc.category}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-emerald-400 font-semibold">
                      {doc.valueProtectedINR}
                    </td>
                    <td className="py-3 px-3 text-neutral-300 font-sans text-[11px]">
                      {doc.counsel}
                    </td>
                    <td className="py-3 px-3 text-amber-300 text-[11px]">
                      {doc.nextRenewalDue}
                    </td>
                    <td className="py-3 px-3 text-[11px]">
                      <span className="text-emerald-400 flex items-center gap-1">
                        <Lock className="w-3 h-3" />
                        <span>AIRGAP_SECURE</span>
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
