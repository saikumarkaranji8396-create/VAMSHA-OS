import React, { useState } from 'react';
import { STAFF_MEMBERS } from '../data/mockVamshaData';
import { StaffMember } from '../types/vamsha';
import {
  Users,
  AlertOctagon,
  ShieldAlert,
  Search,
  Filter,
  CheckCircle,
  EyeOff,
  UserX,
  CreditCard,
  FileSpreadsheet,
  Lock
} from 'lucide-react';

export const VamshaStaffOS: React.FC = () => {
  const [staffList, setStaffList] = useState<StaffMember[]>(STAFF_MEMBERS);
  const [searchQuery, setSearchQuery] = useState('');
  const [riskFilter, setRiskFilter] = useState<'ALL' | 'RED' | 'YELLOW' | 'GREEN'>('ALL');
  const [selectedStaff, setSelectedStaff] = useState<StaffMember | null>(STAFF_MEMBERS[0]);
  const [actionNotice, setActionNotice] = useState<string | null>(null);

  const handleAction = (staffId: string, actionType: string) => {
    setStaffList((prev) =>
      prev.map((s) => {
        if (s.id === staffId) {
          return {
            ...s,
            actionTaken: true,
            riskLevel: actionType === 'TERMINATE' ? 'RED' : 'YELLOW',
          };
        }
        return s;
      })
    );
    setActionNotice(`Confidential directive [${actionType}] executed for staff record ${staffId}. Biometric logs updated.`);
    setTimeout(() => setActionNotice(null), 4000);
  };

  const filteredStaff = staffList.filter((s) => {
    const matchesSearch =
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesRisk = riskFilter === 'ALL' || s.riskLevel === riskFilter;
    return matchesSearch && matchesRisk;
  });

  const redCount = staffList.filter((s) => s.riskLevel === 'RED').length;
  const yellowCount = staffList.filter((s) => s.riskLevel === 'YELLOW').length;
  const greenCount = staffList.filter((s) => s.riskLevel === 'GREEN').length;

  return (
    <div className="space-y-6">
      {/* Module Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-amber-400 font-mono tracking-wider uppercase mb-1">
            <span>MODULE 4</span>
            <span aria-hidden="true">·</span>
            <span>VAMSHA-M4-STAFF</span>
            <span aria-hidden="true">·</span>
            <span>CONFIDENTIAL STAFF OS</span>
          </div>
          <h2 className="text-xl font-semibold text-white tracking-tight">
            Staff Intelligence & Discretionary Risk Audit
          </h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            50 Domestic & Executive Staff: WhatsApp check-in tracking, advance anomaly audits, location leak alarms, and security patrol compliance.
          </p>
        </div>

        <div className="flex items-center gap-2 p-1 bg-rose-950/40 border border-rose-800/60 rounded text-xs text-rose-300 font-mono px-3 py-1.5">
          <EyeOff className="w-4 h-4 text-rose-400 shrink-0" />
          <span>CONFIDENTIAL TO PRINCIPAL ONLY · NEVER EXPOSE TO STAFF</span>
        </div>
      </div>

      {actionNotice && (
        <div className="p-3 bg-emerald-950/40 border border-emerald-800/80 rounded text-xs text-emerald-300 flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{actionNotice}</span>
        </div>
      )}

      {/* Staff Metrics Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-[#0C101A] border border-neutral-800 rounded-lg p-3.5">
          <span className="text-[11px] font-mono text-neutral-400 uppercase block mb-1">Total Active Staff</span>
          <div className="text-xl font-bold font-mono text-white tabular-nums">50 Personnel</div>
          <div className="text-[11px] text-neutral-400 mt-1">Bangalore · Goa · Alibaug · Aviation</div>
        </div>

        <div className="bg-[#0C101A] border border-neutral-800 rounded-lg p-3.5">
          <span className="text-[11px] font-mono text-neutral-400 uppercase block mb-1">WhatsApp Attendance</span>
          <div className="text-xl font-bold font-mono text-emerald-400 tabular-nums">96.0% Today</div>
          <div className="text-[11px] text-neutral-400 mt-1">GPS & Voice verification check-ins</div>
        </div>

        <div className="bg-[#0C101A] border border-neutral-800 rounded-lg p-3.5">
          <span className="text-[11px] font-mono text-neutral-400 uppercase block mb-1">Total Monthly Payroll</span>
          <div className="text-xl font-bold font-mono text-white tabular-nums">₹38.4 Lakhs</div>
          <div className="text-[11px] text-neutral-400 mt-1">Direct NEFT via Kotak Corporate Payroll</div>
        </div>

        <div className="bg-[#0C101A] border border-neutral-800 rounded-lg p-3.5">
          <span className="text-[11px] font-mono text-neutral-400 uppercase block mb-1">Active Red Flags</span>
          <div className="text-xl font-bold font-mono text-rose-400 tabular-nums">{redCount} Red · {yellowCount} Yellow</div>
          <div className="text-[11px] text-rose-300/80 mt-1">Immediate intervention recommended</div>
        </div>
      </div>

      {/* Main Staff Master Grid & Detail Pane */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left Column: Staff Table & Filter (7 Cols) */}
        <div className="lg:col-span-7 bg-[#0C101A] border border-neutral-800 rounded-lg p-4 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-2.5 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search staff by ID, name, role..."
                className="w-full bg-[#080B11] border border-neutral-700 rounded px-2.5 py-1.5 pl-8 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-500"
              />
            </div>

            {/* Risk Filter */}
            <div className="flex items-center gap-1 p-0.5 bg-neutral-900 border border-neutral-800 rounded text-xs">
              <button
                onClick={() => setRiskFilter('ALL')}
                className={`px-2 py-1 text-[11px] rounded transition-colors ${
                  riskFilter === 'ALL' ? 'bg-neutral-800 text-white' : 'text-neutral-400 hover:text-white'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setRiskFilter('RED')}
                className={`px-2 py-1 text-[11px] rounded transition-colors ${
                  riskFilter === 'RED' ? 'bg-rose-950 text-rose-300 border border-rose-800/60' : 'text-rose-400'
                }`}
              >
                Red ({redCount})
              </button>
              <button
                onClick={() => setRiskFilter('YELLOW')}
                className={`px-2 py-1 text-[11px] rounded transition-colors ${
                  riskFilter === 'YELLOW' ? 'bg-amber-950 text-amber-300 border border-amber-800/60' : 'text-amber-400'
                }`}
              >
                Yellow ({yellowCount})
              </button>
              <button
                onClick={() => setRiskFilter('GREEN')}
                className={`px-2 py-1 text-[11px] rounded transition-colors ${
                  riskFilter === 'GREEN' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800/60' : 'text-emerald-400'
                }`}
              >
                Green ({greenCount})
              </button>
            </div>
          </div>

          {/* List of Staff Rows */}
          <div className="space-y-2 max-h-[540px] overflow-y-auto pr-1">
            {filteredStaff.map((staff) => {
              const isSelected = selectedStaff?.id === staff.id;

              return (
                <div
                  key={staff.id}
                  onClick={() => setSelectedStaff(staff)}
                  className={`p-3 rounded-lg border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-neutral-900 border-amber-500/80 shadow-md'
                      : 'bg-[#080B11] border-neutral-800 hover:border-neutral-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] font-mono text-neutral-400">{staff.id}</span>
                      <h4 className="text-xs font-semibold text-white">{staff.name}</h4>
                    </div>

                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                        staff.riskLevel === 'RED'
                          ? 'bg-rose-950 text-rose-300 border border-rose-800/60'
                          : staff.riskLevel === 'YELLOW'
                          ? 'bg-amber-950 text-amber-300 border border-amber-800/60'
                          : 'bg-emerald-950 text-emerald-300 border border-emerald-800/60'
                      }`}
                    >
                      RISK: {staff.riskLevel}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-neutral-400 mt-1">
                    <span>{staff.role}</span>
                    <span className="font-mono text-neutral-300">₹{(staff.monthlySalaryINR / 1000).toFixed(0)}K/mo</span>
                  </div>

                  <p className="text-[11px] text-neutral-400 mt-1.5 line-clamp-2">
                    {staff.evidence}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Detailed Intelligence & Discretionary Action Console (5 Cols) */}
        <div className="lg:col-span-5 bg-[#0C101A] border border-neutral-800 rounded-lg p-5 flex flex-col justify-between space-y-4">
          {selectedStaff ? (
            <div className="space-y-4">
              <div className="border-b border-neutral-800 pb-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono text-amber-400">{selectedStaff.id}</span>
                  <span
                    className={`text-xs font-mono px-2 py-0.5 rounded ${
                      selectedStaff.riskLevel === 'RED'
                        ? 'bg-rose-950 text-rose-300'
                        : selectedStaff.riskLevel === 'YELLOW'
                        ? 'bg-amber-950 text-amber-300'
                        : 'bg-emerald-950 text-emerald-300'
                    }`}
                  >
                    RISK LEVEL: {selectedStaff.riskLevel}
                  </span>
                </div>
                <h3 className="text-base font-semibold text-white mt-1">{selectedStaff.name}</h3>
                <p className="text-xs text-neutral-400">{selectedStaff.role} · {selectedStaff.assignedLocation}</p>
              </div>

              {/* Financial & WhatsApp Status */}
              <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-[#080B11] p-3 rounded border border-neutral-800">
                <div>
                  <span className="text-neutral-500 text-[10px] block">MONTHLY PAYROLL:</span>
                  <span className="text-white">₹{selectedStaff.monthlySalaryINR.toLocaleString()}</span>
                </div>
                <div>
                  <span className="text-neutral-500 text-[10px] block">ADVANCE REQUESTS:</span>
                  <span className={selectedStaff.advancesRequestedCount >= 3 ? 'text-rose-400 font-semibold' : 'text-neutral-300'}>
                    {selectedStaff.advancesRequestedCount}x this month {selectedStaff.lastAdvanceAmountINR > 0 ? `(₹${selectedStaff.lastAdvanceAmountINR.toLocaleString()})` : ''}
                  </span>
                </div>
                <div className="col-span-2 pt-1 border-t border-neutral-800">
                  <span className="text-neutral-500 text-[10px] block">WHATSAPP CHECK-IN STATUS:</span>
                  <span className="text-neutral-300 text-[11px]">{selectedStaff.lastWhatsAppCheckIn}</span>
                </div>
              </div>

              {/* Forensic Evidence Dossier */}
              <div className="p-3 bg-[#080B11] border border-neutral-800 rounded space-y-1.5 text-xs">
                <span className="text-[10px] font-mono text-amber-400 uppercase font-semibold block">
                  Surveillance & Telemetry Evidence:
                </span>
                <p className="text-neutral-200 leading-relaxed text-xs">
                  {selectedStaff.evidence}
                </p>
              </div>

              {/* Recommended Action */}
              <div className="p-3 bg-neutral-900 border border-neutral-800 rounded text-xs space-y-1">
                <span className="text-[10px] font-mono text-neutral-400 uppercase block">
                  Recommended Discretionary Protocol:
                </span>
                <div className="text-white font-medium">
                  {selectedStaff.recommendedAction.replace(/_/g, ' ')}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 border-t border-neutral-800 space-y-2">
                <div className="text-[11px] font-mono text-neutral-400 uppercase">
                  Execute Confidential Order:
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => handleAction(selectedStaff.id, 'FORMAL_WARNING')}
                    className="px-3 py-2 text-xs font-medium bg-neutral-900 hover:bg-neutral-800 text-amber-300 border border-neutral-700 rounded transition-colors"
                  >
                    Dispatch Encrypted Warning
                  </button>
                  <button
                    onClick={() => handleAction(selectedStaff.id, 'DISCREET_AUDIT')}
                    className="px-3 py-2 text-xs font-medium bg-neutral-900 hover:bg-neutral-800 text-sky-300 border border-neutral-700 rounded transition-colors"
                  >
                    Deploy Forensic Audit
                  </button>
                  <button
                    onClick={() => handleAction(selectedStaff.id, 'FREEZE_CARD')}
                    className="px-3 py-2 text-xs font-medium bg-neutral-900 hover:bg-neutral-800 text-rose-300 border border-neutral-700 rounded transition-colors flex items-center justify-center gap-1.5"
                  >
                    <CreditCard className="w-3.5 h-3.5" />
                    <span>Freeze Corporate Card</span>
                  </button>
                  <button
                    onClick={() => handleAction(selectedStaff.id, 'TERMINATE')}
                    className="px-3 py-2 text-xs font-medium bg-rose-950 hover:bg-rose-900 text-rose-200 border border-rose-800 rounded transition-colors flex items-center justify-center gap-1.5"
                  >
                    <UserX className="w-3.5 h-3.5" />
                    <span>Revoke & Terminate</span>
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-neutral-500 text-xs text-center py-16">
              Select a staff member from the ledger to view forensic dossier and execute discretionary actions.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
