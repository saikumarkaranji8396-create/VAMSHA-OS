import React, { useState, useEffect } from 'react';
import { AuthSession, BillingState } from '../types/vamsha';
import {
  ShieldCheck,
  Smartphone,
  Lock,
  KeyRound,
  AlertTriangle,
  Receipt,
  FileCheck2,
  Building2,
  Clock,
  ArrowRight,
  Download,
  AlertOctagon,
  Eye,
  EyeOff,
  LogOut,
  RefreshCw
} from 'lucide-react';

interface AuthBillingProps {
  session: AuthSession;
  billing: BillingState;
  onUpdateSession: (session: AuthSession) => void;
  onUpdateBilling: (billing: BillingState) => void;
  onCloseGate?: () => void;
}

export const VamshaAuthBilling: React.FC<AuthBillingProps> = ({
  session,
  billing,
  onUpdateSession,
  onUpdateBilling,
}) => {
  // Login Form States
  const [phoneNumber, setPhoneNumber] = useState('+91 98450 11999');
  const [otpStep, setOtpStep] = useState<'PHONE' | 'OTP' | 'PASSWORD' | 'AUTHENTICATED'>(
    session.isAuthenticated ? 'AUTHENTICATED' : 'PHONE'
  );
  const [otpInput, setOtpInput] = useState('');
  const [otpTimer, setOtpTimer] = useState(120);
  const [otpAttempts, setOtpAttempts] = useState(0);
  const [lockoutTimer, setLockoutTimer] = useState(0);
  const [securityPassword, setSecurityPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // Billing modal states
  const [activeInvoiceModal, setActiveInvoiceModal] = useState<BillingState['invoices'][0] | null>(null);
  const [activeFircModal, setActiveFircModal] = useState<boolean>(false);

  // OTP Countdown timer
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (otpStep === 'OTP' && otpTimer > 0) {
      interval = setInterval(() => {
        setOtpTimer((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [otpStep, otpTimer]);

  // Lockout countdown timer
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (lockoutTimer > 0) {
      interval = setInterval(() => {
        setLockoutTimer((prev) => {
          if (prev <= 1) {
            setOtpAttempts(0);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [lockoutTimer]);

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    if (!phoneNumber || phoneNumber.trim().length < 8) {
      setAuthError('Enter a valid mobile number with country code (+91, +971, +1, +44).');
      return;
    }
    if (lockoutTimer > 0) {
      setAuthError(`Security lockdown active. Try again in ${Math.floor(lockoutTimer / 60)}m ${lockoutTimer % 60}s.`);
      return;
    }
    setOtpStep('OTP');
    setOtpTimer(120);
    setOtpInput('774921'); // Pre-fill sample OTP for seamless testing
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);

    if (otpTimer <= 0) {
      setAuthError('OTP has expired (2 min limit). Please request a fresh OTP.');
      return;
    }

    if (otpInput.trim().length !== 6) {
      const nextAttempts = otpAttempts + 1;
      setOtpAttempts(nextAttempts);
      if (nextAttempts >= 3) {
        setLockoutTimer(900); // 15 mins
        setAuthError('Maximum OTP attempts exceeded (3/3). System locked down for 15 minutes to protect Principal account.');
      } else {
        setAuthError(`Invalid 6-digit OTP. Attempt ${nextAttempts}/3.`);
      }
      return;
    }

    // OTP passed, advance to second factor: Security Password
    setOtpStep('PASSWORD');
  };

  const handleVerifyPassword = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);

    // Rule: Min 8 chars, must have special character
    const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(securityPassword);
    if (securityPassword.length < 8 || !hasSpecialChar) {
      setAuthError('Security Password must be at least 8 characters and contain at least one special character (!@#$%^&*). Only Family Principal can authenticate.');
      return;
    }

    // Success: Issue JWT valid 24h
    const now = Date.now();
    const token = `eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.vamsha-macmini-${now}-principal`;
    const updated: AuthSession = {
      ...session,
      isAuthenticated: true,
      phone: phoneNumber,
      jwtToken: token,
      issuedAt: now,
      expiresAt: now + 86400000, // 24 hours
      device: 'Mac Studio M4 Ultra / iPhone 16 Pro Max',
      ip: '103.21.144.18 (Bangalore Dedicated Leased Line)',
      country: 'India',
      isNewCountryAlert: false,
    };

    onUpdateSession(updated);
    setOtpStep('AUTHENTICATED');
  };

  const handleLogout = () => {
    onUpdateSession({
      ...session,
      isAuthenticated: false,
      jwtToken: null,
      issuedAt: null,
      expiresAt: null,
    });
    setOtpStep('PHONE');
    setOtpInput('');
    setSecurityPassword('');
    setAuthError(null);
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="space-y-6">
      {/* Module Title & System Status Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-amber-400 font-mono tracking-wider uppercase mb-1">
            <span>MODULE 8</span>
            <span aria-hidden="true">·</span>
            <span>VAMSHA-M0-AUTH-BILLING</span>
            <span aria-hidden="true">·</span>
            <span>AIR-GAPPED HARDWARE GATE</span>
          </div>
          <h2 className="text-xl font-semibold text-white tracking-tight">
            Authentication Enclave & Sovereign Rent Ledger
          </h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            Two-tier bi-factor verification (Mobile OTP + Principal Master Key). Automatic ICICI EEFC USD $50,000/mo settlement.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {session.isAuthenticated ? (
            <button
              onClick={handleLogout}
              className="px-3 py-1.5 text-xs font-medium text-neutral-300 hover:text-white bg-neutral-900 hover:bg-neutral-800 border border-neutral-700 rounded transition-colors flex items-center gap-1.5"
            >
              <LogOut className="w-3.5 h-3.5 text-rose-400" />
              <span>Lock Terminal & Terminate JWT</span>
            </button>
          ) : (
            <div className="text-xs text-rose-400 font-mono flex items-center gap-1">
              <Lock className="w-3.5 h-3.5" />
              <span>GATE ACTIVE · TERMINAL LOCKED</span>
            </div>
          )}
        </div>
      </div>

      {/* If Not Authenticated: Render High-Security Dual-Factor Login Gate */}
      {!session.isAuthenticated ? (
        <div className="max-w-md mx-auto my-8 bg-[#0C101A] border border-neutral-800 rounded-lg p-6 shadow-2xl">
          <div className="text-center mb-6">
            <div className="w-12 h-12 rounded-full bg-amber-950/60 border border-amber-600/30 flex items-center justify-center mx-auto mb-3">
              <ShieldCheck className="w-6 h-6 text-amber-400" />
            </div>
            <h3 className="text-base font-semibold text-white">VAMSHA Sovereign Gate</h3>
            <p className="text-xs text-neutral-400 mt-1">
              Billionaire Family Office Restricted Enclave. Access restricted to Family Principal Srikanth V. Rao.
            </p>
          </div>

          {authError && (
            <div className="mb-4 p-3 bg-rose-950/40 border border-rose-800/60 rounded text-xs text-rose-300 flex items-start gap-2">
              <AlertOctagon className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <span>{authError}</span>
            </div>
          )}

          {lockoutTimer > 0 && (
            <div className="mb-4 p-3 bg-amber-950/40 border border-amber-800/60 rounded text-xs text-amber-300 flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-400 shrink-0" />
              <span>
                Terminal locked down for {Math.floor(lockoutTimer / 60)}m {lockoutTimer % 60}s due to failed attempts.
              </span>
            </div>
          )}

          {otpStep === 'PHONE' && (
            <form onSubmit={handleSendOtp} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">
                  1. Mobile Number (Indian / International)
                </label>
                <div className="relative">
                  <Smartphone className="w-4 h-4 text-neutral-500 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    placeholder="+91 98450 11999 or +971 50 123 4567"
                    className="w-full bg-[#080B11] border border-neutral-700 rounded px-3 py-2 pl-9 text-xs font-mono text-white placeholder-neutral-500 focus:outline-none focus:border-amber-500"
                    required
                  />
                </div>
                <p className="text-[11px] text-neutral-500 mt-1">
                  Accepts +91 (India), +971 (Dubai), +1 (US), +44 (UK).
                </p>
              </div>

              <button
                type="submit"
                disabled={lockoutTimer > 0}
                className="w-full py-2 px-4 bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-neutral-950 font-semibold text-xs rounded transition-colors flex items-center justify-center gap-2"
              >
                <span>Dispatch Encrypted 6-Digit OTP</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </form>
          )}

          {otpStep === 'OTP' && (
            <form onSubmit={handleVerifyOtp} className="space-y-4">
              <div className="p-2.5 bg-neutral-900/80 border border-neutral-800 rounded text-xs text-neutral-300 flex items-center justify-between">
                <span>OTP sent to: <strong className="font-mono text-white">{phoneNumber}</strong></span>
                <button
                  type="button"
                  onClick={() => setOtpStep('PHONE')}
                  className="text-amber-400 hover:underline text-[11px]"
                >
                  Change
                </button>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-medium text-neutral-300">
                    2. Enter 6-Digit OTP
                  </label>
                  <span className={`text-[11px] font-mono ${otpTimer < 30 ? 'text-rose-400' : 'text-neutral-400'}`}>
                    Expires in {formatTime(otpTimer)}
                  </span>
                </div>
                <input
                  type="text"
                  maxLength={6}
                  value={otpInput}
                  onChange={(e) => setOtpInput(e.target.value)}
                  placeholder="774921"
                  className="w-full bg-[#080B11] border border-neutral-700 rounded px-3 py-2 text-center text-lg font-mono tracking-widest text-white placeholder-neutral-600 focus:outline-none focus:border-amber-500"
                  required
                />
                <div className="flex items-center justify-between mt-1 text-[11px] text-neutral-500">
                  <span>Max 3 attempts (Current: {otpAttempts}/3)</span>
                  <button
                    type="button"
                    onClick={() => {
                      setOtpTimer(120);
                      setOtpInput('882914');
                    }}
                    className="text-amber-400 hover:underline flex items-center gap-1"
                  >
                    <RefreshCw className="w-3 h-3" /> Resend
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={lockoutTimer > 0}
                className="w-full py-2 px-4 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-semibold text-xs rounded transition-colors flex items-center justify-center gap-2"
              >
                <span>Verify OTP & Proceed to Principal Key</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </form>
          )}

          {otpStep === 'PASSWORD' && (
            <form onSubmit={handleVerifyPassword} className="space-y-4">
              <div className="p-2.5 bg-emerald-950/30 border border-emerald-800/40 rounded text-xs text-emerald-300">
                OTP verified successfully.
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1">
                  3. Principal Security Password (Tier-2 Barrier)
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-neutral-500 absolute left-3 top-2.5" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={securityPassword}
                    onChange={(e) => setSecurityPassword(e.target.value)}
                    placeholder="Min 8 chars with special char (e.g. Rao#Dynasty2026)"
                    className="w-full bg-[#080B11] border border-neutral-700 rounded px-3 py-2 pl-9 pr-9 text-xs font-mono text-white placeholder-neutral-500 focus:outline-none focus:border-amber-500"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-2.5 text-neutral-400 hover:text-white"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <p className="text-[11px] text-neutral-500 mt-1">
                  Set by Family Principal only. Staff cannot set or reset this key.
                </p>
                <button
                  type="button"
                  onClick={() => setSecurityPassword('Vamsha#Bangalore99!')}
                  className="mt-1 text-[11px] text-amber-400 hover:underline"
                >
                  (Fill demo principal key: Vamsha#Bangalore99!)
                </button>
              </div>

              <button
                type="submit"
                className="w-full py-2 px-4 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-semibold text-xs rounded transition-colors flex items-center justify-center gap-2"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>Issue 24-Hour Sovereign JWT & Unlock</span>
              </button>
            </form>
          )}
        </div>
      ) : null}

      {/* Authenticated State: Active Session Details & Device Security */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Active Session & JWT */}
        <div className="bg-[#0C101A] border border-neutral-800 rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs font-semibold text-white uppercase tracking-wider">
              Principal Identity
            </h3>
            <span className="text-[11px] font-mono text-emerald-400">AUTHENTICATED</span>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex items-center justify-between text-neutral-400">
              <span>Principal:</span>
              <span className="text-white font-medium">{session.principalName}</span>
            </div>
            <div className="flex items-center justify-between text-neutral-400">
              <span>Verified Mobile:</span>
              <span className="text-white font-mono">{session.phone}</span>
            </div>
            <div className="flex items-center justify-between text-neutral-400">
              <span>JWT Validity:</span>
              <span className="text-emerald-400 font-mono">24 Hours (Active)</span>
            </div>
            <div className="flex items-center justify-between text-neutral-400">
              <span>Current Device:</span>
              <span className="text-neutral-200">{session.device}</span>
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-neutral-800 text-[11px] font-mono text-neutral-500 truncate">
            JWT: {session.jwtToken || 'None'}
          </div>
        </div>

        {/* IP & Geolocation Security Auditor */}
        <div className="bg-[#0C101A] border border-neutral-800 rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs font-semibold text-white uppercase tracking-wider">
              Enclave Network Audit
            </h3>
            <span className="text-[11px] font-mono text-amber-400">LEASING ENFORCED</span>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex items-center justify-between text-neutral-400">
              <span>Registered Node IP:</span>
              <span className="text-white font-mono text-[11px]">{session.ip}</span>
            </div>
            <div className="flex items-center justify-between text-neutral-400">
              <span>Origin Jurisdiction:</span>
              <span className="text-white font-medium">{session.country}</span>
            </div>
            <div className="flex items-center justify-between text-neutral-400">
              <span>New Country Alert:</span>
              <span className={session.isNewCountryAlert ? 'text-rose-400 font-semibold' : 'text-neutral-400'}>
                {session.isNewCountryAlert ? 'FLAGGED (Dubai Login)' : 'Nominal (No anomalous geoshifts)'}
              </span>
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-neutral-800">
            <span className="text-[11px] text-neutral-400">Audit Rule: </span>
            <span className="text-[11px] text-neutral-500">
              All logins logged: device, IP, location. Automated WhatsApp SOS to Principal if country code shifts without flight manifest.
            </span>
          </div>
        </div>

        {/* Billing Policy Contract */}
        <div className="bg-[#0C101A] border border-neutral-800 rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs font-semibold text-white uppercase tracking-wider">
              Sovereign Operating Rent
            </h3>
            <span className="text-[11px] font-mono text-amber-400">NO NEGOTIATION</span>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex items-center justify-between text-neutral-400">
              <span>Monthly Rent:</span>
              <span className="text-white font-mono font-semibold">$50,000 / month</span>
            </div>
            <div className="flex items-center justify-between text-neutral-400">
              <span>One-Time Setup:</span>
              <span className="text-neutral-300 font-mono">$10,000 (Settled)</span>
            </div>
            <div className="flex items-center justify-between text-neutral-400">
              <span>Debit Cadence:</span>
              <span className="text-neutral-300">1st of every month</span>
            </div>
            <div className="flex items-center justify-between text-neutral-400">
              <span>Payment Channel:</span>
              <span className="text-neutral-300 font-mono text-[11px]">ICICI EEFC (USD)</span>
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-neutral-800 flex items-center justify-between text-[11px]">
            <span className="text-neutral-400">Fail Protocol:</span>
            <span className="text-rose-400 font-mono">7d Grace → Read-Only → 15d Halt</span>
          </div>
        </div>
      </div>

      {/* Billing Ledger & Invoices Section */}
      <div className="bg-[#0C101A] border border-neutral-800 rounded-lg p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div>
            <h3 className="text-sm font-semibold text-white">
              Sovereign Rent Ledger & Compliance Certificates
            </h3>
            <p className="text-xs text-neutral-400">
              Auto-debit from Family Office ICICI EEFC Account. Includes Karnataka GSTIN and Bank FIRC for RBI FEMA compliance.
            </p>
          </div>

          {/* Test Status Toggles */}
          <div className="flex items-center gap-1.5 p-1 bg-neutral-900 border border-neutral-800 rounded">
            <button
              onClick={() => onUpdateBilling({ ...billing, status: 'ACTIVE' })}
              className={`px-2.5 py-1 text-[11px] font-medium rounded transition-colors ${
                billing.status === 'ACTIVE'
                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-700/60'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              Active
            </button>
            <button
              onClick={() => onUpdateBilling({ ...billing, status: 'GRACE_PERIOD', gracePeriodDaysLeft: 5 })}
              className={`px-2.5 py-1 text-[11px] font-medium rounded transition-colors ${
                billing.status === 'GRACE_PERIOD'
                  ? 'bg-amber-950 text-amber-300 border border-amber-700/60'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              Simulate Grace (5d)
            </button>
            <button
              onClick={() => onUpdateBilling({ ...billing, status: 'READ_ONLY' })}
              className={`px-2.5 py-1 text-[11px] font-medium rounded transition-colors ${
                billing.status === 'READ_ONLY'
                  ? 'bg-rose-950 text-rose-300 border border-rose-700/60'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              Read-Only
            </button>
          </div>
        </div>

        {billing.status === 'GRACE_PERIOD' && (
          <div className="mb-4 p-3 bg-amber-950/40 border border-amber-800/80 rounded text-xs text-amber-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
              <span>
                <strong>Warning:</strong> Monthly EEFC debit pending. Grace period remaining: <strong>{billing.gracePeriodDaysLeft} days</strong>. System will enter Read-Only mode on Day 8.
              </span>
            </div>
            <button
              onClick={() => onUpdateBilling({ ...billing, status: 'ACTIVE' })}
              className="px-2.5 py-1 bg-amber-500 text-neutral-950 text-[11px] font-semibold rounded hover:bg-amber-400 transition-colors"
            >
              Execute Instant Retry
            </button>
          </div>
        )}

        {billing.status === 'READ_ONLY' && (
          <div className="mb-4 p-3 bg-rose-950/50 border border-rose-800 rounded text-xs text-rose-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertOctagon className="w-4 h-4 text-rose-400 shrink-0" />
              <span>
                <strong>Read-Only Mode Enforced:</strong> 7-day grace period elapsed. Actions disabled. Server shutdown in 8 days.
              </span>
            </div>
            <button
              onClick={() => onUpdateBilling({ ...billing, status: 'ACTIVE' })}
              className="px-2.5 py-1 bg-rose-600 text-white text-[11px] font-semibold rounded hover:bg-rose-500 transition-colors"
            >
              Authorize Wire & Restore
            </button>
          </div>
        )}

        {/* Invoice Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-neutral-800 text-neutral-400 font-mono uppercase text-[11px]">
                <th className="py-2.5 px-3">Invoice ID</th>
                <th className="py-2.5 px-3">Billing Period</th>
                <th className="py-2.5 px-3">Amount (USD)</th>
                <th className="py-2.5 px-3">Amount (INR)</th>
                <th className="py-2.5 px-3">Settlement Account</th>
                <th className="py-2.5 px-3">Compliance</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60 font-mono">
              {billing.invoices.map((inv) => (
                <tr key={inv.id} className="hover:bg-neutral-900/40">
                  <td className="py-3 px-3 font-medium text-white">{inv.id}</td>
                  <td className="py-3 px-3 text-neutral-300 font-sans">{inv.period}</td>
                  <td className="py-3 px-3 text-emerald-400 font-semibold tabular-nums">
                    ${inv.amountUSD.toLocaleString()}
                  </td>
                  <td className="py-3 px-3 text-neutral-300 tabular-nums">
                    ₹{(inv.amountINR / 100000).toFixed(2)} Lakhs
                  </td>
                  <td className="py-3 px-3 text-neutral-400 text-[11px] font-sans">
                    ICICI EEFC (**4812)
                  </td>
                  <td className="py-3 px-3 text-[11px] font-sans">
                    <span className="text-neutral-400">GST 18% · </span>
                    <span className="text-amber-400">FIRC Issued</span>
                  </td>
                  <td className="py-3 px-3 text-right font-sans">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => setActiveInvoiceModal(inv)}
                        className="px-2 py-1 text-[11px] font-medium text-neutral-300 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded transition-colors flex items-center gap-1"
                      >
                        <Receipt className="w-3 h-3 text-amber-400" />
                        <span>GST Invoice</span>
                      </button>
                      <button
                        onClick={() => setActiveFircModal(true)}
                        className="px-2 py-1 text-[11px] font-medium text-neutral-300 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded transition-colors flex items-center gap-1"
                      >
                        <FileCheck2 className="w-3 h-3 text-emerald-400" />
                        <span>FIRC</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* GST Invoice Modal */}
      {activeInvoiceModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0C101A] border border-neutral-700 rounded-lg max-w-lg w-full p-6 text-xs text-neutral-300 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <div>
                <h4 className="text-sm font-semibold text-white">VAMSHA Tax Invoice & GST Receipt</h4>
                <p className="text-[11px] text-neutral-400">Rule 46 of CGST Rules, 2017</p>
              </div>
              <button
                onClick={() => setActiveInvoiceModal(null)}
                className="text-neutral-400 hover:text-white font-mono text-sm"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 text-[11px]">
              <div>
                <span className="text-neutral-500 block">Billed To (Family Office):</span>
                <strong className="text-white block">Srikanth V. Rao Family Office</strong>
                <span>Lavelle Road, Bangalore 560001</span>
                <span className="block text-neutral-400">GSTIN: {billing.gstNumber}</span>
              </div>
              <div>
                <span className="text-neutral-500 block">Service Provider:</span>
                <strong className="text-white block">VAMSHA Sovereign OS Inc.</strong>
                <span>Sovereign Enclave Systems Bangalore</span>
                <span className="block text-neutral-400">SAC Code: 998313 (IT Systems)</span>
              </div>
            </div>

            <div className="p-3 bg-neutral-900 rounded space-y-1.5 font-mono">
              <div className="flex justify-between">
                <span>Invoice ID:</span>
                <span className="text-white">{activeInvoiceModal.id}</span>
              </div>
              <div className="flex justify-between">
                <span>Base Rent:</span>
                <span className="text-white">${activeInvoiceModal.amountUSD.toLocaleString()} (₹{activeInvoiceModal.amountINR.toLocaleString()})</span>
              </div>
              <div className="flex justify-between text-neutral-400">
                <span>CGST (9%):</span>
                <span>₹{activeInvoiceModal.gstBreakdown.cgst.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-neutral-400">
                <span>SGST (9%):</span>
                <span>₹{activeInvoiceModal.gstBreakdown.sgst.toLocaleString()}</span>
              </div>
              <div className="flex justify-between pt-1 border-t border-neutral-800 font-semibold text-emerald-400">
                <span>Settlement Status:</span>
                <span>PAID via ICICI EEFC Auto-Debit</span>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setActiveInvoiceModal(null)}
                className="px-3 py-1.5 bg-neutral-800 text-neutral-300 hover:text-white rounded"
              >
                Close
              </button>
              <button
                onClick={() => {
                  alert('Tax Invoice PDF downloaded to local secure enclave.');
                  setActiveInvoiceModal(null);
                }}
                className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-semibold rounded flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download Digitally Signed GST PDF</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* FIRC Modal */}
      {activeFircModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0C101A] border border-neutral-700 rounded-lg max-w-lg w-full p-6 text-xs text-neutral-300 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <div className="flex items-center gap-2">
                <Building2 className="w-4 h-4 text-emerald-400" />
                <h4 className="text-sm font-semibold text-white">Foreign Inward Remittance Certificate (FIRC)</h4>
              </div>
              <button
                onClick={() => setActiveFircModal(false)}
                className="text-neutral-400 hover:text-white font-mono text-sm"
              >
                ✕
              </button>
            </div>

            <div className="space-y-2 font-mono text-[11px] bg-neutral-900 p-3 rounded">
              <div className="flex justify-between">
                <span className="text-neutral-500">Authorized Dealer Bank:</span>
                <span className="text-white">ICICI Bank Ltd, Overseas Branch, Bangalore</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-500">FIRC Certificate Ref:</span>
                <span className="text-emerald-400 font-semibold">{billing.fircNumber}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-500">Remittance Currency / Sum:</span>
                <span className="text-white">USD 50,000.00</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-500">Purpose Code (RBI):</span>
                <span className="text-neutral-200">P0802 - Software consultancy and implementation</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-500">Account Debited:</span>
                <span className="text-neutral-200">EEFC USD 000205004812</span>
              </div>
            </div>

            <p className="text-[11px] text-neutral-400">
              This certificate constitutes statutory proof of legitimate foreign currency settlement in full compliance with RBI Foreign Exchange Management Act (FEMA).
            </p>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setActiveFircModal(false)}
                className="px-3 py-1.5 bg-neutral-800 text-neutral-300 hover:text-white rounded"
              >
                Dismiss
              </button>
              <button
                onClick={() => {
                  alert('Bank FIRC Certificate downloaded.');
                  setActiveFircModal(false);
                }}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-medium rounded flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export Official Bank Copy</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
