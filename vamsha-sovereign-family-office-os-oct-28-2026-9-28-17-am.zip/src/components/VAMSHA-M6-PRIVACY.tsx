import React, { useState } from 'react';
import { PRIVACY_AUDIT_LOGS } from '../data/mockVamshaData';
import { PrivacyShieldLog } from '../types/vamsha';
import {
  ShieldAlert,
  HardDrive,
  Cpu,
  Lock,
  Trash2,
  AlertOctagon,
  CheckCircle2,
  Flame,
  Radio,
  FileCheck,
  Server
} from 'lucide-react';

export const VamshaPrivacyShield: React.FC = () => {
  const [logs, setLogs] = useState<PrivacyShieldLog[]>(PRIVACY_AUDIT_LOGS);
  const [simulatingLeak, setSimulatingLeak] = useState(false);
  const [bannerNotice, setBannerNotice] = useState<string | null>(null);

  const handleSimulateOutboundLeak = () => {
    setSimulatingLeak(true);
    setTimeout(() => {
      const newBlockedLog: PrivacyShieldLog = {
        id: `SHLD-${Math.floor(1000 + Math.random() * 9000)}`,
        timestamp: 'Just now',
        sourceModule: 'M1-CHIEF-OF-STAFF',
        destinationAttempted: 'https://api.openai.com/v1/embeddings',
        dataType: 'Flight manifest with Principal passport number',
        decision: 'BLOCKED_AND_ISOLATED',
        reason: 'CRITICAL INTERCEPT: Attempted outbound API call containing passport biometric string blocked. Forced local fallback to Ollama running on Mac Mini.',
      };

      setLogs([newBlockedLog, ...logs]);
      setSimulatingLeak(false);
      setBannerNotice('SHIELD INTERCEPT SUCCESS: Cloud outbound leak blocked & isolated instantly.');
      setTimeout(() => setBannerNotice(null), 4000);
    }, 700);
  };

  const handlePurgeLogs = () => {
    setLogs((prev) => prev.slice(0, 2));
    setBannerNotice('PURGE COMPLETE: All telemetry older than 7 days shredded with DOD 5220.22-M 7-pass wipe.');
    setTimeout(() => setBannerNotice(null), 4000);
  };

  return (
    <div className="space-y-6">
      {/* Module Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-rose-400 font-mono tracking-wider uppercase mb-1">
            <span>MODULE 6</span>
            <span aria-hidden="true">·</span>
            <span>VAMSHA-M6-PRIVACY</span>
            <span aria-hidden="true">·</span>
            <span>SOVEREIGN AIR-GAP SHIELD</span>
          </div>
          <h2 className="text-xl font-semibold text-white tracking-tight">
            Privacy Shield & Air-Gapped Mac Mini Enclave
          </h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            Zero data to Google, AWS, OpenAI. Dedicated local Mac Mini M4 Pro server in Bangalore vault. Paranoid outbound packet inspection.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleSimulateOutboundLeak}
            disabled={simulatingLeak}
            className="px-3 py-1.5 text-xs font-semibold bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white rounded transition-colors flex items-center gap-1.5 shadow"
          >
            <AlertOctagon className="w-3.5 h-3.5" />
            <span>{simulatingLeak ? 'Intercepting...' : 'Test Cloud PII Leak Defense'}</span>
          </button>
          <button
            onClick={handlePurgeLogs}
            className="px-3 py-1.5 text-xs font-medium bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-700 rounded transition-colors flex items-center gap-1.5"
          >
            <Trash2 className="w-3.5 h-3.5 text-amber-400" />
            <span>Force 7-Day Purge</span>
          </button>
        </div>
      </div>

      {bannerNotice && (
        <div className="p-3 bg-rose-950/40 border border-rose-800/80 rounded text-xs text-rose-300 flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{bannerNotice}</span>
        </div>
      )}

      {/* The 4 Sovereign Mandates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Mandate 1 */}
        <div className="bg-[#0C101A] border border-neutral-800 rounded-lg p-4 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono text-amber-400 uppercase">MANDATE 1</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <h4 className="text-xs font-semibold text-white">All Embeddings Local</h4>
          <p className="text-xs text-neutral-400">
            Ollama running Llama-3.3-70B on Apple Silicon M4 Neural Engine. Zero tokens leave hardware bus.
          </p>
          <div className="text-[10px] font-mono text-emerald-400 pt-1">STATUS: ENFORCED</div>
        </div>

        {/* Mandate 2 */}
        <div className="bg-[#0C101A] border border-neutral-800 rounded-lg p-4 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono text-amber-400 uppercase">MANDATE 2</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <h4 className="text-xs font-semibold text-white">WhatsApp On-Device</h4>
          <p className="text-xs text-neutral-400">
            Domestic staff check-ins & location voice notes parsed strictly on local sandbox. No cloud Meta sync.
          </p>
          <div className="text-[10px] font-mono text-emerald-400 pt-1">STATUS: AIR-GAPPED</div>
        </div>

        {/* Mandate 3 */}
        <div className="bg-[#0C101A] border border-neutral-800 rounded-lg p-4 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono text-amber-400 uppercase">MANDATE 3</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <h4 className="text-xs font-semibold text-white">Bank Encrypted at Rest</h4>
          <p className="text-xs text-neutral-400">
            30 accounts balance sheets encrypted via hardware AES-256-GCM enclave key. Key resides only on Principal phone.
          </p>
          <div className="text-[10px] font-mono text-emerald-400 pt-1">STATUS: HARDWARE LOCKED</div>
        </div>

        {/* Mandate 4 */}
        <div className="bg-[#0C101A] border border-neutral-800 rounded-lg p-4 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono text-amber-400 uppercase">MANDATE 4</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <h4 className="text-xs font-semibold text-white">Auto-Delete After 7 Days</h4>
          <p className="text-xs text-neutral-400">
            Cron daemon purges all raw audio, GPS, and sensor logs every 168 hours to ensure zero subpoena footprint.
          </p>
          <div className="text-[10px] font-mono text-emerald-400 pt-1">NEXT PURGE: 3h 14m</div>
        </div>
      </div>

      {/* Hardware Telemetry Strip */}
      <div className="p-4 bg-[#0C101A] border border-neutral-800 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs font-mono">
        <div className="flex items-center gap-3">
          <Server className="w-5 h-5 text-amber-400" />
          <div>
            <span className="text-white font-semibold">Node: Mac-Mini-M4-Pro (Bangalore Vault #01)</span>
            <span className="text-neutral-400 block text-[11px]">RAM: 64GB Unified · OS: Darwin Sovereign Enclave · IP: 10.0.0.1 (Isolated LAN)</span>
          </div>
        </div>

        <div className="flex items-center gap-4 text-[11px]">
          <div>
            <span className="text-neutral-500 block">CLOUD LEAKAGE:</span>
            <span className="text-emerald-400 font-semibold">0.00 BYTES</span>
          </div>
          <div>
            <span className="text-neutral-500 block">DNS SINKHOLE:</span>
            <span className="text-emerald-400 font-semibold">PI-HOLE AIRGAP ACTIVE</span>
          </div>
          <div>
            <span className="text-neutral-500 block">LOCAL MODEL:</span>
            <span className="text-white">OLLAMA / LLAMA-3.3-70B</span>
          </div>
        </div>
      </div>

      {/* Paranoid Audit Log Stream */}
      <div className="bg-[#0C101A] border border-neutral-800 rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-[11px] font-mono text-rose-400 font-semibold uppercase">
              PARANOID PACKET INTERCEPTION AUDIT REPORT
            </span>
            <h3 className="text-sm font-semibold text-white mt-0.5">
              Live Firewall & Deep Packet Inspection Records
            </h3>
          </div>
          <span className="text-xs text-neutral-400 font-mono">
            {logs.filter((l) => l.decision === 'BLOCKED_AND_ISOLATED').length} Threats Neutralized
          </span>
        </div>

        <div className="space-y-2.5">
          {logs.map((log) => (
            <div
              key={log.id}
              className={`p-3.5 rounded-lg border text-xs space-y-1.5 ${
                log.decision === 'BLOCKED_AND_ISOLATED'
                  ? 'bg-[#080B11] border-rose-900/60'
                  : 'bg-[#080B11] border-neutral-800'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-amber-400 text-[11px]">{log.id}</span>
                  <span className="text-neutral-500 font-mono text-[11px]">· {log.timestamp}</span>
                  <span className="font-mono px-1.5 py-0.2 bg-neutral-900 text-neutral-300 rounded text-[10px] border border-neutral-800">
                    {log.sourceModule}
                  </span>
                </div>

                <span
                  className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                    log.decision === 'BLOCKED_AND_ISOLATED'
                      ? 'bg-rose-950 text-rose-300 border border-rose-800/80'
                      : 'bg-emerald-950 text-emerald-300 border border-emerald-800/80'
                  }`}
                >
                  {log.decision}
                </span>
              </div>

              <div className="flex items-center justify-between text-[11px] font-mono text-neutral-400">
                <span>Attempted Destination: <span className="text-rose-400">{log.destinationAttempted}</span></span>
                <span>Payload: <span className="text-neutral-200">{log.dataType}</span></span>
              </div>

              <p className="text-xs text-neutral-300 leading-relaxed pt-1">
                <strong>Enforcement Audit:</strong> {log.reason}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
