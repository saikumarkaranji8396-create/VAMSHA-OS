import React, { useState } from 'react';
import { ChiefOfStaffResponse } from '../types/vamsha';
import {
  Send,
  Plane,
  CheckCircle2,
  Clock,
  Sparkles,
  Shield,
  ArrowRight,
  MessageSquare,
  Building,
  UserCheck
} from 'lucide-react';

const PRESET_COMMANDS = [
  'Move family to Dubai tomorrow',
  'Charter Bombardier to Zurich for WEF Davos, prep Chalet staff',
  'Host 40-seat private dinner at Bangalore residence for AI founders this Friday',
  'Relocate kids to Mayfair London townhouse for summer IB preparation',
];

const INITIAL_RESPONSE: ChiefOfStaffResponse = {
  query: 'Move family to Dubai tomorrow',
  ack: 'Acknowledged, Sir. Mobilizing your Bombardier Global 7500 (VT-VMS) at HAL Executive Airport for 07:30 IST wheels-up to Dubai Al Maktoum (DWC). Palm Jumeirah Frond N staff and close protection detail placed on high-alert.',
  checklist: [
    {
      step: 1,
      title: 'Jet Booking & Flight Plan Filing',
      details: 'Captain Rajesh filed IFR flight plan VOBG -> OMDW for Bombardier Global 7500. Slot allocated at 07:45 IST. Fuel tanks topped with 18,400 lbs Jet A-1.',
      status: 'COMPLETED',
      autoActionTriggered: 'HAL Private Terminal VIP lounge cleared & apron access code generated.',
    },
    {
      step: 2,
      title: 'UAE Golden Visa & Passport Clearance',
      details: 'Verified biometric validity of all 4 family passports. All active on 10-year UAE Golden Visas (Investors & Real Estate Category). No entry stamps needed.',
      status: 'COMPLETED',
    },
    {
      step: 3,
      title: 'Dubai Villa Staff Alert',
      details: 'Dispatched encrypted instructions to Palm Jumeirah House Manager Tariq: Chilled AC set to 21°C, Maybach 62S ready at DWC private hangar, fresh organic provisions stocked.',
      status: 'DISPATCHED',
      autoActionTriggered: 'Pool heater set to 28°C; guest wing security cameras synced to Bangalore monitor.',
    },
    {
      step: 4,
      title: 'Kids School Leave Notification',
      details: 'Drafted formal travel exemption notice to The International School Bangalore (TISB) Principal for Aarav Rao and Mallya Aditi for Ananya. Synchronized offline tutoring schedules.',
      status: 'IN_PROGRESS',
    },
    {
      step: 5,
      title: 'Calendar & Meeting Reschedule',
      details: 'Rescheduled 4 Bangalore boardroom sessions (including Kotak Private Equity LP review) to encrypted Zoom telepresence or deferred to Monday.',
      status: 'COMPLETED',
    },
    {
      step: 6,
      title: 'Diplomatic & Close Protection Clearance',
      details: 'Lead Protection Officer Vikramaditya coordinated tarmac clearance with Dubai Police VIP Protection Unit & Bangalore City Police Escort to HAL.',
      status: 'DISPATCHED',
    },
    {
      step: 7,
      title: 'Packing List & Vault Dispatch to Spouse',
      details: 'Sent bespoke private WhatsApp memo to Mrs. Radhika Rao detailing climate profile (Dubai 31°C/24°C), formal evening attire for Burj Al Arab dinner, and locked jewelry transfer.',
      status: 'COMPLETED',
    },
  ],
  autoActions: [
    {
      action: 'Dispatched encrypted flight manifest to DGCA & UAE GCAA authorities.',
      target: 'DGCA / UAE Air Traffic Control',
      status: 'EXECUTED_CONFIDENTIAL',
    },
    {
      action: 'Notified Palm Jumeirah head chef of dietary requirements and arrival dinner menu.',
      target: 'Dubai Villa Kitchen',
      status: 'EXECUTED_CONFIDENTIAL',
    },
    {
      action: 'TISB & Mallya Aditi school portal leave forms submitted with digital signature.',
      target: 'International School Registrars',
      status: 'DISPATCHED_TO_CONCIERGE',
    },
    {
      action: 'Held ₹15 Cr liquid buffer in ICICI EEFC account for UAE transaction clearance.',
      target: 'ICICI Wealth Treasury',
      status: 'EXECUTED_CONFIDENTIAL',
    },
  ],
  timestamp: 'Today, 10:45 IST',
  urgency: 'CRITICAL',
};

export const VamshaChiefOfStaff: React.FC = () => {
  const [inputCommand, setInputCommand] = useState('');
  const [response, setResponse] = useState<ChiefOfStaffResponse>(INITIAL_RESPONSE);
  const [isProcessing, setIsProcessing] = useState(false);
  const [history, setHistory] = useState<ChiefOfStaffResponse[]>([INITIAL_RESPONSE]);

  const handleExecuteCommand = (cmdText: string) => {
    if (!cmdText.trim()) return;
    setIsProcessing(true);

    setTimeout(() => {
      const lower = cmdText.toLowerCase();
      let generated: ChiefOfStaffResponse;

      if (lower.includes('davos') || lower.includes('zurich')) {
        generated = {
          query: cmdText,
          ack: 'Acknowledged, Sir. Mobilizing Gulfstream G650ER (N-788VR) for Zurich Kloten (LSZH) non-stop from Kempegowda (VOBL). St. Moritz Chalet manager alerted; snowcat transfer and WEF delegation credentials confirmed.',
          checklist: [
            { step: 1, title: 'Jet Booking & Alpine Overflight', details: 'Flight plan filed for G650ER direct to LSZH (9 hrs 10 mins). De-icing slot reserved.', status: 'COMPLETED' },
            { step: 2, title: 'Schengen Diplomatic/Investor Clearance', details: 'Swiss biometric clearance confirmed for Principal & Chief of Security.', status: 'COMPLETED' },
            { step: 3, title: 'St. Moritz Chalet Staff Alert', details: 'Chalet manager Hans alerted; floor heating set to 22°C; fireplace logs stocked; cellar unlocked.', status: 'DISPATCHED' },
            { step: 4, title: 'Kids Caretaker Handover', details: 'Nanny Fatima & estate guards briefed for Lavelle Road supervision while Principal in Switzerland.', status: 'COMPLETED' },
            { step: 5, title: 'WEF Bilateral Reschedule', details: 'Confirmed 6 closed-door sessions with sovereign wealth funds (ADIA, Temasek, GIC) at Belvedere Hotel.', status: 'COMPLETED' },
            { step: 6, title: 'Swiss Armed Detail Clearance', details: 'Armed protection protocol authorized with Graubünden cantonal police.', status: 'DISPATCHED' },
            { step: 7, title: 'Alpine Packing Manifest', details: 'Delivered bespoke winter wardrobe list and heated cashmere ensemble dispatch to valet.', status: 'COMPLETED' },
          ],
          autoActions: [
            { action: 'Booked VIP helicopter transfer from Zurich Airport to St. Moritz heliport.', target: 'Swiss Air-Rescue / Heliswiss', status: 'EXECUTED_CONFIDENTIAL' },
            { action: 'Transferred 250,000 CHF operational contingency to UBS Zurich private banking vault.', target: 'UBS Wealth Management', status: 'EXECUTED_CONFIDENTIAL' },
            { action: 'Encrypted satellite comms test verified on Gulfstream Ku-band terminal.', target: 'Viasat Sovereign Network', status: 'EXECUTED_CONFIDENTIAL' },
          ],
          timestamp: 'Just now',
          urgency: 'HIGH',
        };
      } else if (lower.includes('dinner') || lower.includes('founder')) {
        generated = {
          query: cmdText,
          ack: 'Acknowledged, Sir. Private dining protocol initiated at Bangalore Lavelle residence for 40 guests this Friday at 19:30 IST. Sommelier and Executive Chef alerted; valet parking and NDA security perimeter deployed.',
          checklist: [
            { step: 1, title: 'Catering & Sommelier Sourcing', details: 'Chef Alessandro instructed on 7-course tasting menu with pure vegetarian luxury pairings. Cellar opened for 2010 Chateau Margaux.', status: 'COMPLETED' },
            { step: 2, title: 'Guest List & Non-Disclosure Protocol', details: 'Invitations dispatched via confidential WhatsApp concierge to 40 unicorn founders; private NDA check-in activated.', status: 'DISPATCHED' },
            { step: 3, title: 'Residence Staffing Expansion', details: 'Engaged 12 additional vetted Oberoi-trained silver-service butlers for terrace & formal dining room.', status: 'COMPLETED' },
            { step: 4, title: 'Kids Quiet Wing Quarantine', details: 'Arranged soundproofing and private theater screening for Aarav and Ananya on 3rd floor penthouse.', status: 'COMPLETED' },
            { step: 5, title: 'Friday Schedule Clearance', details: 'Cleared afternoon calendar post 16:00 IST for Principal dressing and bilateral preview briefings.', status: 'COMPLETED' },
            { step: 6, title: 'Security Perimeter & Valet Staging', details: 'Bangalore traffic police liaisoned for Lavelle Road corridor; 30-car valet holding at UB City.', status: 'DISPATCHED' },
            { step: 7, title: 'Floral & Gifting Logistics', details: 'Imported Dutch white lilies and bespoke Silver Filigree Mysore mementos packed for guests.', status: 'COMPLETED' },
          ],
          autoActions: [
            { action: 'Blocked cell-phone camera stickers issued to all incoming catering contractors.', target: 'Kroll Security detail', status: 'EXECUTED_CONFIDENTIAL' },
            { action: 'Reserved 20 standby suites at Ritz-Carlton Bangalore for out-of-town founder guests.', target: 'Hotel Concierge Direct', status: 'EXECUTED_CONFIDENTIAL' },
          ],
          timestamp: 'Just now',
          urgency: 'HIGH',
        };
      } else {
        generated = {
          query: cmdText,
          ack: `Acknowledged, Sir. Executing sovereign operational directives for: "${cmdText}". All internal family office protocols mobilized instantly.`,
          checklist: [
            { step: 1, title: 'Aviation & Transit Scheduling', details: 'Assessing runway slots, jet readiness, and private chauffeur staging for immediate movement.', status: 'COMPLETED' },
            { step: 2, title: 'Jurisdictional & Regulatory Check', details: 'Cross-verifying biometric permits, tax residency thresholds, and customs clearances.', status: 'COMPLETED' },
            { step: 3, title: 'Estate Staff Mobilization', details: 'Direct encrypted radio message transmitted to destination estate manager and chef.', status: 'DISPATCHED' },
            { step: 4, title: 'Family Academic & Extracurricular Sync', details: 'Synchronized children schedules with private tutors and school registrars without delay.', status: 'IN_PROGRESS' },
            { step: 5, title: 'Board & Portfolio Reallocation', details: 'Notified family office executive committee; prioritized high-impact approvals.', status: 'COMPLETED' },
            { step: 6, title: 'Close Protection & Route Reconnaissance', details: 'Security command reviewed CCTV feeds and primary/secondary transit corridors.', status: 'DISPATCHED' },
            { step: 7, title: 'Family Briefing & Valet Dispatch', details: 'Dispatched encrypted itinerary directly to Principal mobile and spouse.', status: 'COMPLETED' },
          ],
          autoActions: [
            { action: `Logged directive into immutable Bangalore local ledger.`, target: 'Local Enclave Storage', status: 'EXECUTED_CONFIDENTIAL' },
            { action: `Dispatched encrypted task batch to 4 estate managers.`, target: 'Encrypted Radio Gateway', status: 'EXECUTED_CONFIDENTIAL' },
          ],
          timestamp: 'Just now',
          urgency: 'EXPEDITE',
        };
      }

      setResponse(generated);
      setHistory((prev) => [generated, ...prev]);
      setIsProcessing(false);
      setInputCommand('');
    }, 600);
  };

  return (
    <div className="space-y-6">
      {/* Module Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2 text-xs text-amber-400 font-mono tracking-wider uppercase mb-1">
            <span>MODULE 1</span>
            <span aria-hidden="true">·</span>
            <span>VAMSHA-M1-CHIEF-OF-STAFF</span>
            <span aria-hidden="true">·</span>
            <span>BANGALORE HQ</span>
          </div>
          <h2 className="text-xl font-semibold text-white tracking-tight">
            AI Chief of Staff Console
          </h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            Executive delegation interface. Direct, concise billionaire commands converted into instant operational checklists and automated actions.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs text-neutral-400 font-mono">
          <Shield className="w-3.5 h-3.5 text-emerald-400" />
          <span>ZERO DATA LEAVES SERVER · OFFLINE MAC MINI ENCLAVE</span>
        </div>
      </div>

      {/* Billionaire Direct Command Bar */}
      <div className="bg-[#0C101A] border border-neutral-800 rounded-lg p-4 space-y-3">
        <label className="block text-xs font-semibold text-white tracking-wide uppercase">
          Principal Directive Dispatch
        </label>
        
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleExecuteCommand(inputCommand);
          }}
          className="flex gap-2"
        >
          <div className="relative flex-1">
            <input
              type="text"
              value={inputCommand}
              onChange={(e) => setInputCommand(e.target.value)}
              placeholder='Type like a billionaire: "Move family to Dubai tomorrow" or "Prep Bangalore villa for 40-seat dinner"...'
              className="w-full bg-[#080B11] border border-neutral-700 rounded px-4 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-500"
            />
          </div>
          <button
            type="submit"
            disabled={isProcessing || !inputCommand.trim()}
            className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-neutral-950 font-semibold text-xs rounded transition-colors flex items-center gap-2 whitespace-nowrap shrink-0"
          >
            {isProcessing ? (
              <span>Orchestrating...</span>
            ) : (
              <>
                <Send className="w-3.5 h-3.5" />
                <span>Issue Order</span>
              </>
            )}
          </button>
        </form>

        {/* Quick Presets */}
        <div className="flex flex-wrap items-center gap-2 pt-1">
          <span className="text-[11px] text-neutral-500">Quick Directives:</span>
          {PRESET_COMMANDS.map((cmd, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleExecuteCommand(cmd)}
              className="text-[11px] px-2.5 py-1 bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-800 rounded transition-colors truncate max-w-xs"
            >
              "{cmd}"
            </button>
          ))}
        </div>
      </div>

      {/* 3-Part Output: ACK + CHECKLIST + AUTO-ACTIONS */}
      <div className="space-y-4">
        {/* Part 1: ACK */}
        <div className="bg-[#0C101A] border border-amber-900/40 rounded-lg p-5">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-mono text-amber-400 font-semibold uppercase">
                PART 1: EXECUTIVE ACKNOWLEDGMENT (ACK)
              </span>
              <span className="text-neutral-500 text-xs">·</span>
              <span className="text-xs text-neutral-400 font-mono">{response.timestamp}</span>
            </div>
            <span className="text-[11px] font-mono px-2 py-0.5 bg-amber-950/60 text-amber-300 border border-amber-800/40 rounded">
              Priority: {response.urgency}
            </span>
          </div>
          <p className="text-sm text-neutral-100 font-medium leading-relaxed bg-[#080B11] p-3.5 rounded border border-neutral-800/80">
            "{response.ack}"
          </p>
        </div>

        {/* Part 2: CHECKLIST */}
        <div className="bg-[#0C101A] border border-neutral-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[11px] font-mono text-amber-400 font-semibold uppercase">
                PART 2: OPERATIONAL CHECKLIST (7-POINT BREAKDOWN)
              </span>
              <h3 className="text-sm font-semibold text-white mt-0.5">
                Zero-Question Sovereign Execution Plan
              </h3>
            </div>
            <span className="text-xs font-mono text-neutral-400">
              {response.checklist.filter((c) => c.status === 'COMPLETED').length}/7 Steps Ready
            </span>
          </div>

          <div className="grid grid-cols-1 gap-2.5">
            {response.checklist.map((item) => (
              <div
                key={item.step}
                className="p-3 bg-[#080B11] border border-neutral-800/80 rounded flex items-start gap-3 hover:border-neutral-700 transition-colors"
              >
                <div className="w-6 h-6 rounded bg-neutral-900 border border-neutral-700 flex items-center justify-center font-mono text-xs text-amber-400 shrink-0 mt-0.5">
                  0{item.step}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <h4 className="text-xs font-semibold text-white">{item.title}</h4>
                    <span
                      className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${
                        item.status === 'COMPLETED'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800/50'
                          : item.status === 'DISPATCHED'
                          ? 'bg-sky-950 text-sky-300 border border-sky-800/50'
                          : 'bg-amber-950 text-amber-300 border border-amber-800/50'
                      }`}
                    >
                      {item.status}
                    </span>
                  </div>
                  <p className="text-xs text-neutral-300 mt-1 leading-normal">{item.details}</p>
                  {item.autoActionTriggered && (
                    <div className="mt-1.5 text-[11px] font-mono text-amber-400/90 flex items-center gap-1.5">
                      <Sparkles className="w-3 h-3 text-amber-400 shrink-0" />
                      <span>{item.autoActionTriggered}</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Part 3: AUTO-ACTIONS */}
        <div className="bg-[#0C101A] border border-neutral-800 rounded-lg p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[11px] font-mono text-amber-400 font-semibold uppercase">
                PART 3: CONFIDENTIAL AUTO-ACTIONS EXECUTED
              </span>
              <h3 className="text-sm font-semibold text-white mt-0.5">
                Local Daemon Automations
              </h3>
            </div>
            <span className="text-xs text-emerald-400 font-mono flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>All Daemons Fired</span>
            </span>
          </div>

          <div className="space-y-2">
            {response.autoActions.map((act, idx) => (
              <div
                key={idx}
                className="p-3 bg-[#080B11] border border-neutral-800 rounded flex items-center justify-between gap-3 text-xs"
              >
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                  <span className="text-neutral-200">{act.action}</span>
                </div>
                <div className="flex items-center gap-3 shrink-0">
                  <span className="text-[11px] text-neutral-500 font-mono">Target: {act.target}</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 bg-neutral-900 text-emerald-400 border border-neutral-700 rounded">
                    {act.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
