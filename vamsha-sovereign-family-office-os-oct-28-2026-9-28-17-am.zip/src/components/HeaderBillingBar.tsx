import React from 'react';
import { AuthSession, BillingState, ModuleId } from '../types/vamsha';
import {
  Shield,
  Lock,
  CreditCard,
  Building2,
  FileCheck2,
  AlertTriangle
} from 'lucide-react';

interface HeaderBillingBarProps {
  session: AuthSession;
  billing: BillingState;
  activeModule: ModuleId;
  onSelectModule: (mod: ModuleId) => void;
  onOpenBillingModal?: () => void;
}

export const HeaderBillingBar: React.FC<HeaderBillingBarProps> = ({
  session,
  billing,
  activeModule,
  onSelectModule,
}) => {
  return (
    <div>
      {/* 
        TOP BAR CONTRACT:
        Zone 1: Single text wordmark in display face
        Zone 2: 4-5 concise single-line nav links
        Zone 3: 1 primary action
      */}
      <header className="flex items-center justify-between gap-8 px-6 py-4 bg-[#080B11] border-b border-neutral-800">
        {/* Zone 1: Brand Wordmark (Single text element, no subtitle) */}
        <button
          onClick={() => onSelectModule('m1-chief-of-staff')}
          className="text-lg font-serif font-bold tracking-widest text-amber-400 hover:text-amber-300 transition-colors whitespace-nowrap shrink-0"
        >
          VAMSHA
        </button>

        {/* Zone 2: 4-5 Clean single-line navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-medium text-neutral-400">
          <button
            onClick={() => onSelectModule('m1-chief-of-staff')}
            className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
              activeModule === 'm1-chief-of-staff' ? 'text-amber-400 font-semibold' : ''
            }`}
          >
            Chief of Staff
          </button>
          <button
            onClick={() => onSelectModule('m2-wealth')}
            className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
              activeModule === 'm2-wealth' ? 'text-amber-400 font-semibold' : ''
            }`}
          >
            Wealth Cockpit
          </button>
          <button
            onClick={() => onSelectModule('m3-property')}
            className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
              activeModule === 'm3-property' ? 'text-amber-400 font-semibold' : ''
            }`}
          >
            Property & Assets
          </button>
          <button
            onClick={() => onSelectModule('m4-staff')}
            className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
              activeModule === 'm4-staff' ? 'text-amber-400 font-semibold' : ''
            }`}
          >
            Staff Intelligence
          </button>
          <button
            onClick={() => onSelectModule('m7-edu')}
            className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
              activeModule === 'm7-edu' ? 'text-amber-400 font-semibold' : ''
            }`}
          >
            Education OS
          </button>
        </nav>

        {/* Zone 3: 1 Primary Action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => onSelectModule('m0-billing')}
            className="px-3.5 py-1.5 text-xs font-mono font-medium text-neutral-200 bg-neutral-900 hover:bg-neutral-800 border border-neutral-700 rounded transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
          >
            <Lock className="w-3.5 h-3.5 text-amber-400" />
            <span>{session.isAuthenticated ? 'Sovereign Enclave' : 'Unlock Terminal'}</span>
          </button>
        </div>
      </header>

      {/* Persistent Mandatory Module 8 Sovereign Rent & Node Status Strip */}
      <div className="bg-[#0C101A] border-b border-neutral-800/80 px-6 py-2 flex flex-col md:flex-row md:items-center justify-between gap-2 text-[11px] font-mono">
        <div className="flex flex-wrap items-center gap-2 text-neutral-300">
          <span className="text-amber-400 font-semibold">SOVEREIGN RENT: $50,000 / month</span>
          <span className="text-neutral-600" aria-hidden="true">·</span>
          <span>ICICI EEFC Auto-Debit: <strong className="text-emerald-400">ACTIVE</strong></span>
          <span className="text-neutral-600" aria-hidden="true">·</span>
          <span>Next Billing: <strong className="text-neutral-200">{billing.nextBillingDate}</strong></span>
          <span className="text-neutral-600" aria-hidden="true">·</span>
          <span className="text-neutral-400">GSTIN: {billing.gstNumber.split(' ')[0]}</span>
        </div>

        <div className="flex items-center gap-3 shrink-0 text-neutral-400">
          {billing.status === 'GRACE_PERIOD' && (
            <span className="text-amber-400 font-bold flex items-center gap-1">
              <AlertTriangle className="w-3 h-3" />
              <span>GRACE PERIOD: {billing.gracePeriodDaysLeft} DAYS</span>
            </span>
          )}
          {billing.status === 'READ_ONLY' && (
            <span className="text-rose-400 font-bold">
              READ-ONLY MODE ENFORCED
            </span>
          )}
          <span className="text-neutral-500">Air-Gap Server: Bangalore Lavelle Vault #01</span>
          <button
            onClick={() => onSelectModule('m6-privacy')}
            className="hover:text-amber-400 text-neutral-400 underline transition-colors"
          >
            Audit Shield
          </button>
        </div>
      </div>
    </div>
  );
};
