import React, { useState } from 'react';
import {
  AuthSession,
  BillingState,
  ModuleId,
} from './types/vamsha';
import {
  INITIAL_AUTH_SESSION,
  INITIAL_BILLING,
} from './data/mockVamshaData';

import { HeaderBillingBar } from './components/HeaderBillingBar';
import { VamshaAuthBilling } from './components/VAMSHA-M0-AUTH-BILLING';
import { VamshaChiefOfStaff } from './components/VAMSHA-M1-CHIEF-OF-STAFF';
import { VamshaWealthCockpit } from './components/VAMSHA-M2-WEALTH';
import { VamshaPropertyCommander } from './components/VAMSHA-M3-PROPERTY';
import { VamshaStaffOS } from './components/VAMSHA-M4-STAFF';
import { VamshaLegacyManager } from './components/VAMSHA-M5-LEGACY';
import { VamshaPrivacyShield } from './components/VAMSHA-M6-PRIVACY';
import { VamshaEducationOS } from './components/VAMSHA-M7-EDU';

import {
  Command,
  Coins,
  Building,
  Users,
  Scroll,
  ShieldCheck,
  GraduationCap,
  KeyRound,
  Plane,
  Anchor,
  Lock,
  ArrowRight
} from 'lucide-react';

export default function App() {
  const [session, setSession] = useState<AuthSession>(INITIAL_AUTH_SESSION);
  const [billing, setBilling] = useState<BillingState>(INITIAL_BILLING);
  const [activeModule, setActiveModule] = useState<ModuleId>('m1-chief-of-staff');

  // Module launcher definitions
  const MODULES = [
    {
      id: 'm1-chief-of-staff' as ModuleId,
      code: 'M1',
      name: 'Chief of Staff',
      subtitle: 'Executive Checklists & Directives',
      icon: Command,
      tag: 'AI Chief of Staff',
    },
    {
      id: 'm2-wealth' as ModuleId,
      code: 'M2',
      name: 'Wealth Cockpit',
      subtitle: '30 Banks, Zerodha, Setu, Plaid',
      icon: Coins,
      tag: '₹1,482 Cr / $177M',
    },
    {
      id: 'm3-property' as ModuleId,
      code: 'M3',
      name: 'Property & Assets',
      subtitle: '10 Houses, 3 Jets, 2 Yachts (IoT)',
      icon: Building,
      tag: 'Anomaly Detection',
    },
    {
      id: 'm4-staff' as ModuleId,
      code: 'M4',
      name: 'Staff OS',
      subtitle: '50 Personnel & Red Flag Radar',
      icon: Users,
      tag: '4 Red Flags',
    },
    {
      id: 'm5-legacy' as ModuleId,
      code: 'M5',
      name: 'Legacy & Trusts',
      subtitle: 'Wills, Dynasties, 80G Foundation',
      icon: Scroll,
      tag: 'Cameroon / Withers',
    },
    {
      id: 'm6-privacy' as ModuleId,
      code: 'M6',
      name: 'Privacy Shield',
      subtitle: 'Offline Mac Mini M4 Vault Enclave',
      icon: ShieldCheck,
      tag: 'Zero Cloud Leak',
    },
    {
      id: 'm7-edu' as ModuleId,
      code: 'M7',
      name: 'Education OS',
      subtitle: 'Ivy League / Oxbridge Admissions',
      icon: GraduationCap,
      tag: 'Not Byju’s',
    },
    {
      id: 'm0-billing' as ModuleId,
      code: 'M0',
      name: 'Auth & Billing',
      subtitle: 'Bi-Factor Gate & $50K/mo Ledger',
      icon: KeyRound,
      tag: 'ICICI EEFC USD',
    },
  ];

  // If user is locked out/unauthenticated, gate enforces M0
  const effectiveModule = !session.isAuthenticated ? 'm0-billing' : activeModule;

  return (
    <div className="min-h-screen bg-[#080B11] text-neutral-200 flex flex-col font-sans selection:bg-amber-500/30 selection:text-amber-200">
      {/* Top Bar with Three-Zone Contract + Billing Strip */}
      <HeaderBillingBar
        session={session}
        billing={billing}
        activeModule={effectiveModule}
        onSelectModule={setActiveModule}
      />

      {/* Main Workspace Frame */}
      <div className="flex-1 max-w-[1560px] w-full mx-auto px-4 sm:px-6 py-6 flex flex-col gap-6">
        {/* Sovereign Family Office Context Banner */}
        <div className="relative overflow-hidden rounded-xl border border-neutral-800 bg-[#0C101A] p-6">
          <div className="absolute inset-0 opacity-15 pointer-events-none">
            <img
              src="/src/assets/images/vamsha_sovereign_vault_1793159433462.jpg"
              alt="Vamsha Family Office Sanctuary"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center"
            />
          </div>

          <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div className="space-y-1.5 max-w-2xl">
              <div className="flex items-center gap-2 text-xs font-mono text-amber-400">
                <span>SRIKANTH V. RAO FAMILY OFFICE</span>
                <span aria-hidden="true">·</span>
                <span>LAVELLE ROAD, BANGALORE 560001</span>
                <span aria-hidden="true">·</span>
                <span className="text-emerald-400">ENCLAVE AIRGAP NODE ACTIVE</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-serif font-bold text-white tracking-wide">
                VAMSHA Sovereign Operating System
              </h1>
              <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed text-balance">
                Unified command infrastructure for multi-generational wealth, aviation fleet, global estates, domestic staff intelligence, and Oxbridge/Ivy League heir education.
              </p>
            </div>

            {/* Quick Status Pillows / Metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 shrink-0 font-mono text-xs">
              <div className="bg-[#080B11]/90 border border-neutral-800 rounded p-3">
                <span className="text-neutral-500 text-[10px] block">CONSOLIDATED WEALTH</span>
                <span className="text-sm font-bold text-white tabular-nums">₹1,482.5 Cr</span>
                <span className="text-[10px] text-emerald-400 block">$177.3M (+$502K 24h)</span>
              </div>
              <div className="bg-[#080B11]/90 border border-neutral-800 rounded p-3">
                <span className="text-neutral-500 text-[10px] block">ASSET INVENTORY</span>
                <span className="text-sm font-bold text-white tabular-nums">10 Estates · 3 Jets</span>
                <span className="text-[10px] text-amber-400 block">2 Yachts (Goa & DXB)</span>
              </div>
              <div className="bg-[#080B11]/90 border border-neutral-800 rounded p-3 col-span-2 sm:col-span-1">
                <span className="text-neutral-500 text-[10px] block">SECURITY AUDIT</span>
                <span className="text-sm font-bold text-emerald-400 tabular-nums">100% Air-Gapped</span>
                <span className="text-[10px] text-neutral-400 block">Mac Mini M4 Pro Vault</span>
              </div>
            </div>
          </div>
        </div>

        {/* Module Navigation Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2">
          {MODULES.map((m) => {
            const Icon = m.icon;
            const isActive = effectiveModule === m.id;

            return (
              <button
                key={m.id}
                onClick={() => {
                  if (!session.isAuthenticated && m.id !== 'm0-billing') {
                    setActiveModule('m0-billing');
                  } else {
                    setActiveModule(m.id);
                  }
                }}
                className={`p-3 rounded-lg border text-left transition-all flex flex-col justify-between ${
                  isActive
                    ? 'bg-neutral-900 border-amber-500 shadow-md ring-1 ring-amber-500/30'
                    : 'bg-[#0C101A] border-neutral-800 hover:border-neutral-700 hover:bg-neutral-900/40'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-mono text-amber-400 font-bold">{m.code}</span>
                    <Icon className={`w-4 h-4 ${isActive ? 'text-amber-400' : 'text-neutral-500'}`} />
                  </div>
                  <div className="text-xs font-semibold text-white truncate">{m.name}</div>
                  <div className="text-[10px] text-neutral-400 truncate mt-0.5">{m.subtitle}</div>
                </div>

                <div className="mt-2 pt-2 border-t border-neutral-800/60 flex items-center justify-between text-[9px] font-mono">
                  <span className={isActive ? 'text-amber-300' : 'text-neutral-500'}>
                    {m.tag}
                  </span>
                  {isActive && <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>}
                </div>
              </button>
            );
          })}
        </div>

        {/* Active Module Viewport */}
        <main className="min-h-[500px]">
          {effectiveModule === 'm1-chief-of-staff' && <VamshaChiefOfStaff />}
          {effectiveModule === 'm2-wealth' && <VamshaWealthCockpit />}
          {effectiveModule === 'm3-property' && <VamshaPropertyCommander />}
          {effectiveModule === 'm4-staff' && <VamshaStaffOS />}
          {effectiveModule === 'm5-legacy' && <VamshaLegacyManager />}
          {effectiveModule === 'm6-privacy' && <VamshaPrivacyShield />}
          {effectiveModule === 'm7-edu' && <VamshaEducationOS />}
          {effectiveModule === 'm0-billing' && (
            <VamshaAuthBilling
              session={session}
              billing={billing}
              onUpdateSession={setSession}
              onUpdateBilling={setBilling}
            />
          )}
        </main>
      </div>

      {/* Quiet Footer */}
      <footer className="mt-auto border-t border-neutral-800/80 bg-[#080B11] px-6 py-4 text-xs text-neutral-500 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="font-serif font-bold text-neutral-300">VAMSHA</span>
          <span>·</span>
          <span>Sovereign Family Office Enclave Bangalore</span>
          <span>·</span>
          <span>Version 2026.10</span>
        </div>
        <div className="flex items-center gap-4 font-mono text-[11px] text-neutral-500">
          <span>Ollama Llama-3.3-70B Local Engine</span>
          <span>·</span>
          <span>AES-256-GCM Encrypted Ledger</span>
          <span>·</span>
          <span>No Data Leaves Server</span>
        </div>
      </footer>
    </div>
  );
}
